<?php
/**
 * Configuration du CRM Fibromed
 * -------------------------------------------------------------
 * 1) Copiez ce fichier et renommez la copie "config.php"
 * 2) Remplissez les informations de connexion à votre base de données
 *    (fournies par votre panel Hodi lors de la création de la base MySQL)
 * 3) Ne partagez jamais ce fichier une fois rempli (il contient un mot de passe)
 */

// --- Connexion à la base de données MySQL ---
define('DB_HOST', 'localhost');       // Hôte de la base (souvent "localhost" chez Hodi)
define('DB_NAME', 'fibromed_crm');    // Nom de la base de données MySQL
define('DB_USER', 'votre_utilisateur_mysql');
define('DB_PASS', 'votre_mot_de_passe_mysql');

// --- Adresse de base de l'application (sans slash final) ---
// Exemple : https://crm.fibromed.ma
define('BASE_URL', 'https://crm.fibromed.ma');

// --- Fuseau horaire ---
define('APP_TIMEZONE', 'Africa/Casablanca');

// --- Envoi d'emails (relances, alertes) ---
// Laissez EMAIL_FROM vide pour désactiver l'envoi d'emails automatiques.
define('EMAIL_FROM', 'contact@fibromed.ma');
define('EMAIL_FROM_NAME', 'CRM Fibromed');

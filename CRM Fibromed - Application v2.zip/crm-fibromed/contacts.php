<?php
$pageTitle = 'Contacts';
$activeNav = 'contacts';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();

// --- Filtres ---
$filtreStatut = $_GET['statut'] ?? '';
$filtreSegment = $_GET['segment'] ?? '';
$filtreEtab = $_GET['etablissement'] ?? '';
$recherche = trim($_GET['q'] ?? '');

$where = [];
$params = [];
if ($filtreStatut !== '') { $where[] = 'c.statut_id = ?'; $params[] = $filtreStatut; }
if ($filtreSegment !== '') { $where[] = 'c.segment = ?'; $params[] = $filtreSegment; }
if ($filtreEtab !== '') { $where[] = 'c.etablissement_id = ?'; $params[] = $filtreEtab; }
if ($recherche !== '') {
    $where[] = '(c.prenom LIKE ? OR c.nom LIKE ? OR c.email LIKE ?)';
    $like = '%' . $recherche . '%';
    $params[] = $like; $params[] = $like; $params[] = $like;
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "
    SELECT c.*, e.nom AS etablissement_nom, s.nom AS statut_nom, s.couleur AS statut_couleur
    FROM contacts c
    LEFT JOIN etablissements e ON e.id = c.etablissement_id
    LEFT JOIN statuts s ON s.id = c.statut_id
    $whereSql
    ORDER BY c.created_at DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$contacts = $stmt->fetchAll();

$statuts = getStatuts();
$etablissements = getEtablissementsList();
$prochainesTaches = getProchaineTacheParContact();
$todayIso = todayIso();
?>

<div class="page-header">
  <div>
    <h1>Contacts</h1>
    <div class="sub"><?= count($contacts) ?> contact(s)</div>
  </div>
  <a href="contact_form.php" class="btn">+ Nouveau contact</a>
</div>

<form method="get" class="filters-bar card">
  <div class="form-row">
    <label>Recherche</label>
    <input type="text" name="q" value="<?= e($recherche) ?>" placeholder="Nom, prénom, email...">
  </div>
  <div class="form-row">
    <label>Statut</label>
    <select name="statut">
      <option value="">Tous</option>
      <?php foreach ($statuts as $s): ?>
        <option value="<?= (int)$s['id'] ?>" <?= (string)$filtreStatut === (string)$s['id'] ? 'selected' : '' ?>><?= e($s['nom']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-row">
    <label>Segment</label>
    <select name="segment">
      <option value="">Tous</option>
      <?php foreach (['A','B','C','D'] as $seg): ?>
        <option value="<?= $seg ?>" <?= $filtreSegment === $seg ? 'selected' : '' ?>>Segment <?= $seg ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-row">
    <label>Établissement</label>
    <select name="etablissement">
      <option value="">Tous</option>
      <?php foreach ($etablissements as $e): ?>
        <option value="<?= (int)$e['id'] ?>" <?= (string)$filtreEtab === (string)$e['id'] ? 'selected' : '' ?>><?= e($e['nom']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button type="submit" class="btn btn-secondary">Filtrer</button>
  <a href="contacts.php" class="btn btn-secondary">Réinitialiser</a>
</form>

<?php if (empty($contacts)): ?>
  <div class="card empty-state">Aucun contact ne correspond à ces critères.</div>
<?php else: ?>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>Nom</th><th>Poste</th><th>Établissement</th><th>Segment</th><th>Statut</th><th>Prochaine tâche</th><th></th></tr>
      </thead>
      <tbody>
        <?php foreach ($contacts as $c): ?>
          <tr>
            <td><a href="contact_view.php?id=<?= (int)$c['id'] ?>"><?= e($c['prenom'] . ' ' . $c['nom']) ?></a></td>
            <td><?= e($c['poste'] ?? '—') ?></td>
            <td><?= e($c['etablissement_nom'] ?? '—') ?></td>
            <td><?= $c['segment'] ? e($c['segment']) : '—' ?></td>
            <td><?= $c['statut_nom'] ? '<span class="badge" style="background:' . e($c['statut_couleur']) . '">' . e($c['statut_nom']) . '</span>' : '—' ?></td>
            <?php $prochTache = $prochainesTaches[(int)$c['id']] ?? null; ?>
            <td><?= $prochTache ? (($prochTache < $todayIso) ? '<span class="badge danger">' . formatDateFr($prochTache) . '</span>' : formatDateFr($prochTache)) : '—' ?></td>
            <td class="btn-group">
              <a href="contact_view.php?id=<?= (int)$c['id'] ?>" class="btn btn-sm btn-secondary">Voir</a>
              <a href="contact_form.php?id=<?= (int)$c['id'] ?>" class="btn btn-sm btn-secondary">Modifier</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

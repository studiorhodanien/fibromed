<?php
$pageTitle = 'Contact';
$activeNav = 'contacts';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$contact = [
    'prenom' => '', 'nom' => '', 'poste' => '', 'etablissement_id' => '', 'segment' => '',
    'ville' => '', 'pays' => 'Maroc', 'telephone' => '', 'email' => '', 'linkedin_url' => '',
    'statut_id' => '', 'notes' => ''
];

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM contacts WHERE id = ?');
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) {
        flash('error', "Contact introuvable.");
        redirect('contacts.php');
    }
    $contact = $found;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $contact['prenom'] = trim($_POST['prenom'] ?? '');
    $contact['nom'] = trim($_POST['nom'] ?? '');
    $contact['poste'] = trim($_POST['poste'] ?? '');
    $contact['etablissement_id'] = $_POST['etablissement_id'] ?: null;
    $contact['segment'] = $_POST['segment'] ?: null;
    $contact['ville'] = trim($_POST['ville'] ?? '');
    $contact['pays'] = trim($_POST['pays'] ?? '');
    $contact['telephone'] = trim($_POST['telephone'] ?? '');
    $contact['email'] = trim($_POST['email'] ?? '');
    $contact['linkedin_url'] = trim($_POST['linkedin_url'] ?? '');
    $contact['statut_id'] = $_POST['statut_id'] ?: null;
    $contact['notes'] = trim($_POST['notes'] ?? '');

    if ($contact['prenom'] === '' || $contact['nom'] === '') {
        $errors[] = 'Le prénom et le nom sont obligatoires.';
    }

    if (empty($errors)) {
        if ($id) {
            $stmt = $pdo->prepare('UPDATE contacts SET prenom=?, nom=?, poste=?, etablissement_id=?, segment=?, ville=?, pays=?, telephone=?, email=?, linkedin_url=?, statut_id=?, notes=? WHERE id=?');
            $stmt->execute([
                $contact['prenom'], $contact['nom'], $contact['poste'], $contact['etablissement_id'], $contact['segment'],
                $contact['ville'], $contact['pays'], $contact['telephone'], $contact['email'], $contact['linkedin_url'],
                $contact['statut_id'], $contact['notes'], $id
            ]);
            flash('success', 'Contact mis à jour.');
            redirect('contact_view.php?id=' . $id);
        } else {
            $stmt = $pdo->prepare('INSERT INTO contacts (prenom, nom, poste, etablissement_id, segment, ville, pays, telephone, email, linkedin_url, statut_id, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->execute([
                $contact['prenom'], $contact['nom'], $contact['poste'], $contact['etablissement_id'], $contact['segment'],
                $contact['ville'], $contact['pays'], $contact['telephone'], $contact['email'], $contact['linkedin_url'],
                $contact['statut_id'], $contact['notes']
            ]);
            $newId = $pdo->lastInsertId();
            flash('success', 'Contact créé.');
            redirect('contact_view.php?id=' . $newId);
        }
    }
}

$etablissements = getEtablissementsList();
$statuts = getStatuts();
?>

<div class="page-header">
  <h1><?= $id ? 'Modifier le contact' : 'Nouveau contact' ?></h1>
</div>

<?php foreach ($errors as $err): ?><div class="flash error"><?= e($err) ?></div><?php endforeach; ?>

<div class="card">
  <form method="post" action="contact_form.php<?= $id ? '?id=' . $id : '' ?>">
    <?= csrfField() ?>
    <div class="form-grid">
      <div class="form-row">
        <label>Prénom *</label>
        <input type="text" name="prenom" required value="<?= e($contact['prenom']) ?>">
      </div>
      <div class="form-row">
        <label>Nom *</label>
        <input type="text" name="nom" required value="<?= e($contact['nom']) ?>">
      </div>
      <div class="form-row">
        <label>Poste</label>
        <input type="text" name="poste" value="<?= e($contact['poste']) ?>">
      </div>
      <div class="form-row">
        <label>Établissement</label>
        <select name="etablissement_id">
          <option value="">— Aucun —</option>
          <?php foreach ($etablissements as $e): ?>
            <option value="<?= (int)$e['id'] ?>" <?= (string)$contact['etablissement_id'] === (string)$e['id'] ? 'selected' : '' ?>><?= e($e['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Segment</label>
        <select name="segment">
          <option value="">— Aucun —</option>
          <?php foreach (['A','B','C','D'] as $seg): ?>
            <option value="<?= $seg ?>" <?= $contact['segment'] === $seg ? 'selected' : '' ?>>Segment <?= $seg ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Statut</label>
        <select name="statut_id">
          <option value="">— Aucun —</option>
          <?php foreach ($statuts as $s): ?>
            <option value="<?= (int)$s['id'] ?>" <?= (string)$contact['statut_id'] === (string)$s['id'] ? 'selected' : '' ?>><?= e($s['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Ville</label>
        <input type="text" name="ville" value="<?= e($contact['ville']) ?>">
      </div>
      <div class="form-row">
        <label>Pays</label>
        <input type="text" name="pays" value="<?= e($contact['pays']) ?>">
      </div>
      <div class="form-row">
        <label>Téléphone / WhatsApp</label>
        <input type="tel" name="telephone" value="<?= e($contact['telephone']) ?>">
      </div>
      <div class="form-row">
        <label>Email</label>
        <input type="email" name="email" value="<?= e($contact['email']) ?>">
      </div>
      <div class="form-row">
        <label>Lien LinkedIn</label>
        <input type="url" name="linkedin_url" value="<?= e($contact['linkedin_url']) ?>">
      </div>
    </div>
    <?php if ($id): ?>
      <p class="sub">Pour programmer une relance (appel, réunion, email...), rendez-vous sur la fiche du contact après l'enregistrement.</p>
    <?php endif; ?>
    <div class="form-row">
      <label>Notes</label>
      <textarea name="notes"><?= e($contact['notes']) ?></textarea>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">Enregistrer</button>
      <a href="<?= $id ? 'contact_view.php?id=' . $id : 'contacts.php' ?>" class="btn btn-secondary">Annuler</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

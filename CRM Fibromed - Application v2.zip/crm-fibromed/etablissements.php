<?php
$pageTitle = 'Établissements';
$activeNav = 'etablissements';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$recherche = trim($_GET['q'] ?? '');

$sql = 'SELECT e.*, (SELECT COUNT(*) FROM contacts c WHERE c.etablissement_id = e.id) AS nb_contacts FROM etablissements e';
$params = [];
if ($recherche !== '') {
    $sql .= ' WHERE e.nom LIKE ? OR e.ville LIKE ?';
    $like = '%' . $recherche . '%';
    $params = [$like, $like];
}
$sql .= ' ORDER BY e.nom ASC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$etablissements = $stmt->fetchAll();
?>

<div class="page-header">
  <div>
    <h1>Établissements</h1>
    <div class="sub"><?= count($etablissements) ?> établissement(s)</div>
  </div>
  <a href="etablissement_form.php" class="btn">+ Nouvel établissement</a>
</div>

<form method="get" class="filters-bar card">
  <div class="form-row" style="flex:1;">
    <label>Recherche</label>
    <input type="text" name="q" value="<?= e($recherche) ?>" placeholder="Nom, ville...">
  </div>
  <button type="submit" class="btn btn-secondary">Filtrer</button>
</form>

<?php if (empty($etablissements)): ?>
  <div class="card empty-state">Aucun établissement enregistré.</div>
<?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Nom</th><th>Secteur</th><th>Ville</th><th>Pays</th><th>Contacts</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($etablissements as $e): ?>
          <tr>
            <td><a href="etablissement_view.php?id=<?= (int)$e['id'] ?>"><?= e($e['nom']) ?></a></td>
            <td><?= e($e['secteur'] ?: '—') ?></td>
            <td><?= e($e['ville'] ?: '—') ?></td>
            <td><?= e($e['pays'] ?: '—') ?></td>
            <td><?= (int)$e['nb_contacts'] ?></td>
            <td class="btn-group">
              <a href="etablissement_view.php?id=<?= (int)$e['id'] ?>" class="btn btn-sm btn-secondary">Voir</a>
              <a href="etablissement_form.php?id=<?= (int)$e['id'] ?>" class="btn btn-sm btn-secondary">Modifier</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

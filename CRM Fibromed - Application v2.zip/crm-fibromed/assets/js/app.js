document.addEventListener('DOMContentLoaded', function () {
  // --- Menu mobile ---
  var toggle = document.getElementById('mobile-menu-toggle');
  var sidebar = document.getElementById('sidebar');
  var overlay = document.getElementById('sidebar-overlay');
  if (toggle && sidebar && overlay) {
    toggle.addEventListener('click', function () {
      sidebar.classList.toggle('open');
      overlay.classList.toggle('open');
    });
    overlay.addEventListener('click', function () {
      sidebar.classList.remove('open');
      overlay.classList.remove('open');
    });
  }

  // --- Confirmation avant suppression ---
  document.querySelectorAll('[data-confirm]').forEach(function (el) {
    el.addEventListener('click', function (e) {
      if (!confirm(el.getAttribute('data-confirm'))) {
        e.preventDefault();
      }
    });
  });

  // --- Éditeur de lignes devis/facture ---
  var lignesBody = document.getElementById('lignes-body');
  if (lignesBody) {
    var addBtn = document.getElementById('add-ligne-btn');
    var tvaInput = document.getElementById('taux_tva');

    function rowTemplate(index) {
      return '' +
        '<tr>' +
        '<td><input type="text" name="lignes[' + index + '][designation]" placeholder="Désignation"></td>' +
        '<td style="width:90px"><input type="number" step="0.01" min="0" name="lignes[' + index + '][quantite]" value="1" class="qte"></td>' +
        '<td style="width:130px"><input type="number" step="0.01" min="0" name="lignes[' + index + '][prix_unitaire]" value="0" class="pu"></td>' +
        '<td style="width:130px" class="ligne-total">0,00</td>' +
        '<td style="width:40px"><button type="button" class="btn btn-sm btn-danger remove-ligne">✕</button></td>' +
        '</tr>';
    }

    var rowIndex = lignesBody.querySelectorAll('tr').length;

    addBtn.addEventListener('click', function () {
      lignesBody.insertAdjacentHTML('beforeend', rowTemplate(rowIndex));
      rowIndex++;
      recalculer();
    });

    lignesBody.addEventListener('click', function (e) {
      if (e.target.classList.contains('remove-ligne')) {
        e.target.closest('tr').remove();
        recalculer();
      }
    });

    lignesBody.addEventListener('input', recalculer);
    if (tvaInput) tvaInput.addEventListener('input', recalculer);

    function recalculer() {
      var totalHT = 0;
      lignesBody.querySelectorAll('tr').forEach(function (row) {
        var qte = parseFloat(row.querySelector('.qte') ? row.querySelector('.qte').value : 0) || 0;
        var pu = parseFloat(row.querySelector('.pu') ? row.querySelector('.pu').value : 0) || 0;
        var totalLigne = qte * pu;
        var cell = row.querySelector('.ligne-total');
        if (cell) cell.textContent = totalLigne.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        totalHT += totalLigne;
      });
      var tauxTva = tvaInput ? (parseFloat(tvaInput.value) || 0) : 20;
      var totalTVA = totalHT * (tauxTva / 100);
      var totalTTC = totalHT + totalTVA;

      setText('total-ht', totalHT);
      setText('total-tva', totalTVA);
      setText('total-ttc', totalTTC);
    }

    function setText(id, value) {
      var el = document.getElementById(id);
      if (el) el.textContent = value.toLocaleString('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    recalculer();
  }

  // --- Éditeur de lignes bon de livraison (matériel, sans prix) ---
  var blLignesBody = document.getElementById('bl-lignes-body');
  if (blLignesBody) {
    var addBlBtn = document.getElementById('add-bl-ligne-btn');

    function blRowTemplate(index) {
      return '' +
        '<tr>' +
        '<td><input type="text" name="lignes[' + index + '][designation]" placeholder="Ex : Endoscope souple"></td>' +
        '<td><input type="text" name="lignes[' + index + '][marque]" placeholder="Ex : Olympus"></td>' +
        '<td><input type="text" name="lignes[' + index + '][modele]" placeholder="Ex : GIF-H190"></td>' +
        '<td><input type="text" name="lignes[' + index + '][numero_serie]" placeholder="N° de série"></td>' +
        '<td style="width:80px"><input type="number" step="0.01" min="0" name="lignes[' + index + '][quantite]" value="1"></td>' +
        '<td style="width:40px"><button type="button" class="btn btn-sm btn-danger remove-bl-ligne">✕</button></td>' +
        '</tr>';
    }

    var blRowIndex = blLignesBody.querySelectorAll('tr').length;

    addBlBtn.addEventListener('click', function () {
      blLignesBody.insertAdjacentHTML('beforeend', blRowTemplate(blRowIndex));
      blRowIndex++;
    });

    blLignesBody.addEventListener('click', function (e) {
      if (e.target.classList.contains('remove-bl-ligne')) {
        e.target.closest('tr').remove();
      }
    });
  }
});

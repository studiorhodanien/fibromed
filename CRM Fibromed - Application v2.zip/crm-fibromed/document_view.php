<?php
$pageTitle = 'Document';
$activeNav = 'documents';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare('
    SELECT d.*, e.nom AS etablissement_nom, c.prenom AS contact_prenom, c.nom AS contact_nom,
           bl.numero AS bon_livraison_numero
    FROM documents d
    LEFT JOIN etablissements e ON e.id = d.etablissement_id
    LEFT JOIN contacts c ON c.id = d.contact_id
    LEFT JOIN documents bl ON bl.id = d.bon_livraison_id
    WHERE d.id = ? AND d.type IN (\'devis\',\'facture\')
');
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) {
    flash('error', 'Document introuvable.');
    redirect('documents.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_statut') {
        $stmt = $pdo->prepare('UPDATE documents SET statut = ? WHERE id = ?');
        $stmt->execute([$_POST['statut'], $id]);
        flash('success', 'Statut mis à jour.');
        redirect('document_view.php?id=' . $id);
    }

    if ($action === 'convertir_facture' && $doc['type'] === 'devis') {
        $numero = generateDocumentNumber('facture');
        $stmt = $pdo->prepare('INSERT INTO documents (type, numero, etablissement_id, contact_id, date_emission, date_echeance, statut, taux_tva, total_ht, total_tva, total_ttc, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute(['facture', $numero, $doc['etablissement_id'], $doc['contact_id'], todayIso(), null, 'brouillon', $doc['taux_tva'], $doc['total_ht'], $doc['total_tva'], $doc['total_ttc'], $doc['notes']]);
        $newId = $pdo->lastInsertId();

        $lignesStmt = $pdo->prepare('SELECT * FROM document_lignes WHERE document_id = ?');
        $lignesStmt->execute([$id]);
        $insertLigne = $pdo->prepare('INSERT INTO document_lignes (document_id, designation, quantite, prix_unitaire, ordre) VALUES (?,?,?,?,?)');
        foreach ($lignesStmt->fetchAll() as $l) {
            $insertLigne->execute([$newId, $l['designation'], $l['quantite'], $l['prix_unitaire'], $l['ordre']]);
        }

        $pdo->prepare('UPDATE documents SET converti_en_facture_id = ? WHERE id = ?')->execute([$newId, $id]);

        flash('success', "Facture $numero créée à partir de ce devis.");
        redirect('document_view.php?id=' . $newId);
    }

    if ($action === 'delete') {
        $stmt = $pdo->prepare('DELETE FROM documents WHERE id = ?');
        $stmt->execute([$id]);
        flash('success', 'Document supprimé.');
        redirect('documents.php');
    }
}

$stmt = $pdo->prepare('SELECT * FROM document_lignes WHERE document_id = ? ORDER BY ordre ASC, id ASC');
$stmt->execute([$id]);
$lignes = $stmt->fetchAll();

$statutsListe = ['brouillon' => 'Brouillon', 'envoyé' => 'Envoyé', 'accepté' => 'Accepté', 'payé' => 'Payé', 'en_retard' => 'En retard', 'annulé' => 'Annulé'];
?>

<div class="page-header">
  <div>
    <h1><?= $doc['type'] === 'devis' ? 'Devis' : 'Facture' ?> <?= e($doc['numero']) ?></h1>
    <div class="sub"><?= e($doc['etablissement_nom'] ?: '') ?></div>
  </div>
  <div class="btn-group">
    <a href="document_pdf.php?id=<?= $id ?>" target="_blank" class="btn btn-secondary">Voir le PDF</a>
    <a href="document_pdf.php?id=<?= $id ?>&dl=1" class="btn btn-secondary">Télécharger le PDF</a>
    <a href="document_form.php?id=<?= $id ?>" class="btn btn-secondary">Modifier</a>
    <?php if ($doc['type'] === 'devis' && empty($doc['converti_en_facture_id'])): ?>
      <form method="post" style="display:inline" onsubmit="return confirm('Créer une facture à partir de ce devis ?');">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="convertir_facture">
        <button type="submit" class="btn">Convertir en facture</button>
      </form>
    <?php endif; ?>
    <?php if ($doc['type'] === 'facture' && empty($doc['bon_livraison_numero'])): ?>
      <a href="bon_livraison_form.php?facture_id=<?= $id ?>" class="btn">Créer un bon de livraison</a>
    <?php elseif ($doc['type'] === 'facture' && !empty($doc['bon_livraison_numero'])): ?>
      <a href="bon_livraison_view.php?id=<?= (int)$doc['bon_livraison_id'] ?>" class="btn btn-secondary">Voir le bon de livraison (<?= e($doc['bon_livraison_numero']) ?>)</a>
    <?php endif; ?>
    <form method="post" style="display:inline" onsubmit="return confirm('Supprimer définitivement ce document ?');">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="delete">
      <button type="submit" class="btn btn-danger">Supprimer</button>
    </form>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <h2>Informations</h2>
    <table>
      <tr><td>Établissement</td><td><?= $doc['etablissement_nom'] ? '<a href="etablissement_view.php?id=' . (int)$doc['etablissement_id'] . '">' . e($doc['etablissement_nom']) . '</a>' : '—' ?></td></tr>
      <tr><td>Contact</td><td><?= ($doc['contact_prenom'] || $doc['contact_nom']) ? e($doc['contact_prenom'] . ' ' . $doc['contact_nom']) : '—' ?></td></tr>
      <tr><td>Date d'émission</td><td><?= formatDateFr($doc['date_emission']) ?></td></tr>
      <tr><td>Date d'échéance</td><td><?= formatDateFr($doc['date_echeance']) ?></td></tr>
      <tr><td>Total HT</td><td><?= formatMoney($doc['total_ht']) ?></td></tr>
      <tr><td>TVA (<?= rtrim(rtrim(number_format($doc['taux_tva'], 2), '0'), '.') ?>%)</td><td><?= formatMoney($doc['total_tva']) ?></td></tr>
      <tr><td><strong>Total TTC</strong></td><td><strong><?= formatMoney($doc['total_ttc']) ?></strong></td></tr>
      <?php if ($doc['converti_en_facture_id']): ?>
        <tr><td>Converti en facture</td><td><a href="document_view.php?id=<?= (int)$doc['converti_en_facture_id'] ?>">Voir la facture</a></td></tr>
      <?php endif; ?>
    </table>
  </div>

  <div class="card">
    <h2>Statut</h2>
    <form method="post" class="btn-group" style="align-items:center;">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="update_statut">
      <select name="statut" onchange="this.form.submit()">
        <?php foreach ($statutsListe as $key => $label): ?>
          <option value="<?= e($key) ?>" <?= $doc['statut'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </form>

    <?php if ($doc['notes']): ?>
      <h2 style="margin-top:18px;">Notes</h2>
      <p style="white-space:pre-wrap;"><?= e($doc['notes']) ?></p>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <h2>Lignes</h2>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Désignation</th><th>Qté</th><th>Prix unitaire</th><th>Total</th></tr></thead>
      <tbody>
        <?php foreach ($lignes as $l): ?>
          <tr>
            <td class="wrap"><?= e($l['designation']) ?></td>
            <td><?= rtrim(rtrim(number_format($l['quantite'], 2), '0'), '.') ?></td>
            <td><?= formatMoney($l['prix_unitaire']) ?></td>
            <td><?= formatMoney($l['quantite'] * $l['prix_unitaire']) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

<?php
$pageTitle = 'Réparation';
$activeNav = 'reparations';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$rep = [
    'etablissement_id' => '', 'contact_id' => '', 'marque' => '', 'modele' => '', 'numero_serie' => '',
    'date_reception' => todayIso(), 'date_diagnostic' => '', 'date_fin_prevue' => '', 'date_fin_reelle' => '',
    'garantie_mois' => 6, 'statut' => 'Reçu', 'notes' => ''
];

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM reparations WHERE id = ?');
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) {
        flash('error', 'Réparation introuvable.');
        redirect('reparations.php');
    }
    $rep = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrfCheck();
    $stmt = $pdo->prepare('DELETE FROM reparations WHERE id = ?');
    $stmt->execute([$id]);
    flash('success', 'Réparation supprimée.');
    redirect('reparations.php');
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') !== 'delete') {
    csrfCheck();
    $rep['etablissement_id'] = $_POST['etablissement_id'] ?: null;
    $rep['contact_id'] = $_POST['contact_id'] ?: null;
    $rep['marque'] = trim($_POST['marque'] ?? '');
    $rep['modele'] = trim($_POST['modele'] ?? '');
    $rep['numero_serie'] = trim($_POST['numero_serie'] ?? '');
    $rep['date_reception'] = $_POST['date_reception'] ?: todayIso();
    $rep['date_diagnostic'] = $_POST['date_diagnostic'] ?: null;
    $rep['date_fin_prevue'] = $_POST['date_fin_prevue'] ?: null;
    $rep['date_fin_reelle'] = $_POST['date_fin_reelle'] ?: null;
    $rep['garantie_mois'] = (int)($_POST['garantie_mois'] ?: 6);
    $rep['statut'] = $_POST['statut'] ?? 'Reçu';
    $rep['notes'] = trim($_POST['notes'] ?? '');

    if (empty($errors)) {
        if ($id) {
            $stmt = $pdo->prepare('UPDATE reparations SET etablissement_id=?, contact_id=?, marque=?, modele=?, numero_serie=?, date_reception=?, date_diagnostic=?, date_fin_prevue=?, date_fin_reelle=?, garantie_mois=?, statut=?, notes=? WHERE id=?');
            $stmt->execute([
                $rep['etablissement_id'], $rep['contact_id'], $rep['marque'], $rep['modele'], $rep['numero_serie'],
                $rep['date_reception'], $rep['date_diagnostic'], $rep['date_fin_prevue'], $rep['date_fin_reelle'],
                $rep['garantie_mois'], $rep['statut'], $rep['notes'], $id
            ]);
            flash('success', 'Réparation mise à jour.');
            redirect('reparation_form.php?id=' . $id);
        } else {
            $stmt = $pdo->prepare('INSERT INTO reparations (etablissement_id, contact_id, marque, modele, numero_serie, date_reception, date_diagnostic, date_fin_prevue, date_fin_reelle, garantie_mois, statut, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->execute([
                $rep['etablissement_id'], $rep['contact_id'], $rep['marque'], $rep['modele'], $rep['numero_serie'],
                $rep['date_reception'], $rep['date_diagnostic'], $rep['date_fin_prevue'], $rep['date_fin_reelle'],
                $rep['garantie_mois'], $rep['statut'], $rep['notes']
            ]);
            $newId = $pdo->lastInsertId();
            flash('success', 'Réparation créée.');
            redirect('reparation_form.php?id=' . $newId);
        }
    }
}

$etablissements = getEtablissementsList();
$contactsEtab = $rep['etablissement_id'] ? getContactsByEtablissement((int)$rep['etablissement_id']) : [];
$finGarantie = calculerFinGarantie($rep['date_fin_reelle'], (int)$rep['garantie_mois']);
$statutsListe = ['Reçu','En diagnostic','En réparation','Terminé','Restitué'];
?>

<div class="page-header">
  <h1><?= $id ? 'Dossier de réparation' : 'Nouvelle réparation' ?></h1>
  <?php if ($id): ?>
    <form method="post" onsubmit="return confirm('Supprimer définitivement ce dossier ?');">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="delete">
      <button type="submit" class="btn btn-danger">Supprimer</button>
    </form>
  <?php endif; ?>
</div>

<?php foreach ($errors as $err): ?><div class="flash error"><?= e($err) ?></div><?php endforeach; ?>

<div class="card">
  <form method="post" action="reparation_form.php<?= $id ? '?id=' . $id : '' ?>">
    <?= csrfField() ?>
    <div class="form-grid">
      <div class="form-row">
        <label>Établissement</label>
        <select name="etablissement_id">
          <option value="">— Aucun —</option>
          <?php foreach ($etablissements as $e): ?>
            <option value="<?= (int)$e['id'] ?>" <?= (string)$rep['etablissement_id'] === (string)$e['id'] ? 'selected' : '' ?>><?= e($e['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Contact d'origine</label>
        <select name="contact_id">
          <option value="">— Aucun —</option>
          <?php foreach ($contactsEtab as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= (string)$rep['contact_id'] === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['prenom'] . ' ' . $c['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Marque</label>
        <input type="text" name="marque" placeholder="Olympus, Pentax, Fujifilm..." value="<?= e($rep['marque']) ?>">
      </div>
      <div class="form-row">
        <label>Modèle</label>
        <input type="text" name="modele" value="<?= e($rep['modele']) ?>">
      </div>
      <div class="form-row">
        <label>Numéro de série</label>
        <input type="text" name="numero_serie" value="<?= e($rep['numero_serie']) ?>">
      </div>
      <div class="form-row">
        <label>Statut</label>
        <select name="statut">
          <?php foreach ($statutsListe as $s): ?>
            <option value="<?= e($s) ?>" <?= $rep['statut'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Date de réception</label>
        <input type="date" name="date_reception" value="<?= e($rep['date_reception']) ?>">
      </div>
      <div class="form-row">
        <label>Date de diagnostic</label>
        <input type="date" name="date_diagnostic" value="<?= e($rep['date_diagnostic']) ?>">
      </div>
      <div class="form-row">
        <label>Date de fin prévue</label>
        <input type="date" name="date_fin_prevue" value="<?= e($rep['date_fin_prevue']) ?>">
      </div>
      <div class="form-row">
        <label>Date de fin réelle</label>
        <input type="date" name="date_fin_reelle" value="<?= e($rep['date_fin_reelle']) ?>">
      </div>
      <div class="form-row">
        <label>Garantie (mois)</label>
        <input type="number" name="garantie_mois" min="0" value="<?= (int)$rep['garantie_mois'] ?>">
      </div>
      <div class="form-row">
        <label>Fin de garantie (calculée)</label>
        <input type="text" value="<?= $finGarantie ? formatDateFr($finGarantie) : '—' ?>" disabled>
      </div>
    </div>
    <div class="form-row">
      <label>Notes</label>
      <textarea name="notes"><?= e($rep['notes']) ?></textarea>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">Enregistrer</button>
      <a href="reparations.php" class="btn btn-secondary">Annuler</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

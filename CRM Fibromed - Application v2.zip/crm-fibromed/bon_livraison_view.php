<?php
$pageTitle = 'Bon de livraison';
$activeNav = 'documents';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT d.*, e.nom AS etablissement_nom, c.prenom AS contact_prenom, c.nom AS contact_nom,
           f.numero AS facture_numero
    FROM documents d
    LEFT JOIN etablissements e ON e.id = d.etablissement_id
    LEFT JOIN contacts c ON c.id = d.contact_id
    LEFT JOIN documents f ON f.id = d.facture_source_id
    WHERE d.id = ? AND d.type = 'bon_livraison'
");
$stmt->execute([$id]);
$doc = $stmt->fetch();
if (!$doc) {
    flash('error', 'Bon de livraison introuvable.');
    redirect('documents.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrfCheck();
    $pdo->prepare('UPDATE documents SET bon_livraison_id = NULL WHERE bon_livraison_id = ?')->execute([$id]);
    $pdo->prepare('DELETE FROM documents WHERE id = ?')->execute([$id]);
    flash('success', 'Bon de livraison supprimé.');
    redirect('documents.php');
}

$stmt = $pdo->prepare('SELECT * FROM bon_livraison_lignes WHERE document_id = ? ORDER BY ordre ASC, id ASC');
$stmt->execute([$id]);
$lignes = $stmt->fetchAll();
?>

<div class="page-header">
  <div>
    <h1>Bon de livraison <?= e($doc['numero']) ?></h1>
    <div class="sub"><?= e($doc['etablissement_nom'] ?: '') ?></div>
  </div>
  <div class="btn-group">
    <a href="bon_livraison_pdf.php?id=<?= $id ?>" target="_blank" class="btn btn-secondary">Voir le PDF</a>
    <a href="bon_livraison_pdf.php?id=<?= $id ?>&dl=1" class="btn btn-secondary">Télécharger le PDF</a>
    <a href="bon_livraison_form.php?id=<?= $id ?>" class="btn btn-secondary">Modifier</a>
    <form method="post" style="display:inline" onsubmit="return confirm('Supprimer définitivement ce bon de livraison ?');">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="delete">
      <button type="submit" class="btn btn-danger">Supprimer</button>
    </form>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <h2>Informations</h2>
    <table>
      <tr><td>Établissement</td><td><?= $doc['etablissement_nom'] ? '<a href="etablissement_view.php?id=' . (int)$doc['etablissement_id'] . '">' . e($doc['etablissement_nom']) . '</a>' : '—' ?></td></tr>
      <tr><td>Contact</td><td><?= ($doc['contact_prenom'] || $doc['contact_nom']) ? e($doc['contact_prenom'] . ' ' . $doc['contact_nom']) : '—' ?></td></tr>
      <tr><td>Date de livraison</td><td><?= formatDateFr($doc['date_emission']) ?></td></tr>
      <tr><td>Statut</td><td><?= $doc['statut'] === 'brouillon' ? 'Brouillon' : 'Finalisé / remis au client' ?></td></tr>
      <?php if ($doc['facture_numero']): ?>
        <tr><td>Facture liée</td><td><a href="document_view.php?id=<?= (int)$doc['facture_source_id'] ?>"><?= e($doc['facture_numero']) ?></a></td></tr>
      <?php endif; ?>
    </table>
    <?php if ($doc['notes']): ?>
      <h2 style="margin-top:18px;">Notes</h2>
      <p style="white-space:pre-wrap;"><?= e($doc['notes']) ?></p>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <h2>Matériel livré</h2>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Désignation</th><th>Marque</th><th>Modèle</th><th>N° de série</th><th>Qté</th></tr></thead>
      <tbody>
        <?php foreach ($lignes as $l): ?>
          <tr>
            <td class="wrap"><?= e($l['designation']) ?></td>
            <td><?= e($l['marque'] ?: '—') ?></td>
            <td><?= e($l['modele'] ?: '—') ?></td>
            <td><?= e($l['numero_serie'] ?: '—') ?></td>
            <td><?= rtrim(rtrim(number_format($l['quantite'], 2), '0'), '.') ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

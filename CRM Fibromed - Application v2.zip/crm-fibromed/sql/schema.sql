-- Schéma de base de données — CRM Fibromed (version 2)
-- Charset UTF-8 complet pour supporter tous les caractères (accents, etc.)

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ==========================================================
-- Utilisateurs
-- ==========================================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    nom_complet VARCHAR(150) NOT NULL,
    email VARCHAR(150) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Paramètres de l'entreprise (utilisés sur les devis/factures)
-- ==========================================================
CREATE TABLE IF NOT EXISTS parametres (
    cle VARCHAR(100) PRIMARY KEY,
    valeur TEXT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Statuts du pipeline commercial (personnalisables)
-- ==========================================================
CREATE TABLE IF NOT EXISTS statuts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(100) NOT NULL,
    couleur VARCHAR(7) NOT NULL DEFAULT '#1A2050',
    ordre INT NOT NULL DEFAULT 0,
    actif TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Établissements (hôpitaux / cliniques)
-- ==========================================================
CREATE TABLE IF NOT EXISTS etablissements (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(200) NOT NULL,
    secteur VARCHAR(100) NULL,
    ville VARCHAR(100) NULL,
    pays VARCHAR(100) NULL DEFAULT 'Maroc',
    adresse VARCHAR(255) NULL,
    telephone VARCHAR(50) NULL,
    email VARCHAR(150) NULL,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Contacts (personnes individuelles)
-- ==========================================================
CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prenom VARCHAR(100) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    poste VARCHAR(150) NULL,
    etablissement_id INT NULL,
    segment ENUM('A','B','C','D') NULL,
    ville VARCHAR(100) NULL,
    pays VARCHAR(100) NULL DEFAULT 'Maroc',
    telephone VARCHAR(50) NULL,
    email VARCHAR(150) NULL,
    linkedin_url VARCHAR(255) NULL,
    statut_id INT NULL,
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_contacts_etablissement FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE SET NULL,
    CONSTRAINT fk_contacts_statut FOREIGN KEY (statut_id) REFERENCES statuts(id) ON DELETE SET NULL,
    INDEX idx_contacts_statut (statut_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Historique des interactions (par canal) — évènements déjà passés
-- ==========================================================
CREATE TABLE IF NOT EXISTS interactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contact_id INT NOT NULL,
    canal ENUM('Appel','Email','Réunion','WhatsApp','LinkedIn','Message','Autre') NOT NULL,
    date_interaction DATE NOT NULL,
    note TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_interactions_contact FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE,
    INDEX idx_interactions_contact (contact_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Tâches / relances programmées par l'utilisateur (façon HubSpot)
-- ==========================================================
CREATE TABLE IF NOT EXISTS taches (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contact_id INT NOT NULL,
    type ENUM('Appel','Email','Réunion','WhatsApp','LinkedIn','Message','Autre') NOT NULL DEFAULT 'Appel',
    titre VARCHAR(255) NULL,
    date_prevue DATE NOT NULL,
    statut ENUM('a_faire','fait') NOT NULL DEFAULT 'a_faire',
    note TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL,
    CONSTRAINT fk_taches_contact FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE CASCADE,
    INDEX idx_taches_contact (contact_id),
    INDEX idx_taches_date (date_prevue),
    INDEX idx_taches_statut (statut)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Réparations
-- ==========================================================
CREATE TABLE IF NOT EXISTS reparations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etablissement_id INT NULL,
    contact_id INT NULL,
    marque VARCHAR(100) NULL,
    modele VARCHAR(150) NULL,
    numero_serie VARCHAR(150) NULL,
    date_reception DATE NOT NULL,
    date_diagnostic DATE NULL,
    date_fin_prevue DATE NULL,
    date_fin_reelle DATE NULL,
    garantie_mois INT NOT NULL DEFAULT 6,
    statut ENUM('Reçu','En diagnostic','En réparation','Terminé','Restitué') NOT NULL DEFAULT 'Reçu',
    notes TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_reparations_etablissement FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE SET NULL,
    CONSTRAINT fk_reparations_contact FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL,
    INDEX idx_reparations_statut (statut)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================================
-- Devis / Factures / Bons de livraison
-- ==========================================================
CREATE TABLE IF NOT EXISTS documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('devis','facture','bon_livraison') NOT NULL,
    numero VARCHAR(50) NOT NULL UNIQUE,
    etablissement_id INT NULL,
    contact_id INT NULL,
    date_emission DATE NOT NULL,
    date_echeance DATE NULL,
    statut ENUM('brouillon','envoyé','accepté','payé','en_retard','annulé') NOT NULL DEFAULT 'brouillon',
    taux_tva DECIMAL(5,2) NOT NULL DEFAULT 20.00,
    total_ht DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_tva DECIMAL(12,2) NOT NULL DEFAULT 0,
    total_ttc DECIMAL(12,2) NOT NULL DEFAULT 0,
    notes TEXT NULL,
    converti_en_facture_id INT NULL,
    bon_livraison_id INT NULL,
    facture_source_id INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_documents_etablissement FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE SET NULL,
    CONSTRAINT fk_documents_contact FOREIGN KEY (contact_id) REFERENCES contacts(id) ON DELETE SET NULL,
    INDEX idx_documents_type (type),
    INDEX idx_documents_statut (statut)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Lignes des devis / factures (désignation + prix)
CREATE TABLE IF NOT EXISTS document_lignes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_id INT NOT NULL,
    designation VARCHAR(255) NOT NULL,
    quantite DECIMAL(10,2) NOT NULL DEFAULT 1,
    prix_unitaire DECIMAL(12,2) NOT NULL DEFAULT 0,
    ordre INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_lignes_document FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Lignes des bons de livraison (matériel livré, sans prix)
CREATE TABLE IF NOT EXISTS bon_livraison_lignes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    document_id INT NOT NULL,
    designation VARCHAR(255) NOT NULL,
    marque VARCHAR(100) NULL,
    modele VARCHAR(150) NULL,
    numero_serie VARCHAR(150) NULL,
    quantite DECIMAL(10,2) NOT NULL DEFAULT 1,
    ordre INT NOT NULL DEFAULT 0,
    CONSTRAINT fk_lignes_bl FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ==========================================================
-- Données de départ (seed)
-- ==========================================================

INSERT INTO statuts (nom, couleur, ordre) VALUES
('Nouveau contact', '#6EA8D8', 1),
('En échange', '#B5CC66', 2),
('RDV pris', '#1A2050', 3),
('Devis envoyé', '#E8A33D', 4),
('Client', '#3E8E4F', 5),
('Sans réponse', '#999999', 6);

INSERT INTO parametres (cle, valeur) VALUES
('raison_sociale', 'FIBROMED SARL'),
('rc', '367091'),
('tribunal_rc', 'Tribunal de commerce de Casablanca'),
('if_fiscal', '20725765'),
('ice', '001836205000038'),
('adresse', '7, rue Sebta, résidence Rami, bureau 8, 2ème étage, 20000 Casablanca'),
('telephone', ''),
('email', 'contact@fibromed.ma'),
('taux_tva', '20'),
('prefixe_devis', 'DEV'),
('prefixe_facture', 'FACT'),
('prefixe_bon_livraison', 'BL'),
('email_alertes', ''),
('devise', 'MAD'),
('gerant_nom', 'Aymen Habibellah'),
('gerant_telephone', '+33 6 70 18 71 01'),
('gerant_email', 'a.habib@fibromed.ma'),
('clause_juridique', 'Notre société conserve l''entière propriété des produits livrés jusqu''à l''encaissement effectif et intégral du prix facturé. Tout litige sera à défaut d''accord amiable de la compétence exclusive du tribunal de Casablanca.');

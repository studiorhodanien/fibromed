<?php
$pageTitle = 'Tableau de bord';
$activeNav = 'dashboard';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();

// --- KPIs pipeline ---
$totalContacts = (int)$pdo->query('SELECT COUNT(*) FROM contacts')->fetchColumn();
$statuts = getStatuts();
$repartitionStatuts = $pdo->query('
    SELECT s.id, s.nom, s.couleur, COUNT(c.id) AS total
    FROM statuts s
    LEFT JOIN contacts c ON c.statut_id = s.id
    GROUP BY s.id, s.nom, s.couleur, s.ordre
    ORDER BY s.ordre ASC
')->fetchAll();

$clientStatutId = null;
foreach ($statuts as $s) {
    if (mb_stripos($s['nom'], 'client') !== false) {
        $clientStatutId = $s['id'];
        break;
    }
}
$totalClients = 0;
if ($clientStatutId) {
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM contacts WHERE statut_id = ?');
    $stmt->execute([$clientStatutId]);
    $totalClients = (int)$stmt->fetchColumn();
}
$tauxConversion = $totalContacts > 0 ? round(($totalClients / $totalContacts) * 100, 1) : 0;

// --- Réparations en cours ---
$reparationsEnCours = (int)$pdo->query("SELECT COUNT(*) FROM reparations WHERE statut NOT IN ('Terminé','Restitué')")->fetchColumn();

// --- Chiffre d'affaires ---
$caFacture = (float)$pdo->query("SELECT COALESCE(SUM(total_ttc),0) FROM documents WHERE type='facture' AND statut != 'annulé'")->fetchColumn();
$caEncaisse = (float)$pdo->query("SELECT COALESCE(SUM(total_ttc),0) FROM documents WHERE type='facture' AND statut='payé'")->fetchColumn();

// --- Factures en retard (échéance dépassée et non payées) ---
$facturesEnRetard = $pdo->query("
    SELECT d.*, e.nom AS etablissement_nom
    FROM documents d
    LEFT JOIN etablissements e ON e.id = d.etablissement_id
    WHERE d.type='facture' AND d.statut NOT IN ('payé','annulé') AND d.date_echeance IS NOT NULL AND d.date_echeance < CURDATE()
    ORDER BY d.date_echeance ASC
")->fetchAll();
$montantEnRetard = array_sum(array_column($facturesEnRetard, 'total_ttc'));

// --- Tâches à faire (relances programmées par l'utilisateur) ---
$tachesAFaire = getTachesOuvertes();

// --- Garanties bientôt expirées (dans les 30 prochains jours) ---
$garanties = $pdo->query("
    SELECT r.*, e.nom AS etablissement_nom,
           DATE_ADD(r.date_fin_reelle, INTERVAL r.garantie_mois MONTH) AS fin_garantie
    FROM reparations r
    LEFT JOIN etablissements e ON e.id = r.etablissement_id
    WHERE r.date_fin_reelle IS NOT NULL
    HAVING fin_garantie BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
    ORDER BY fin_garantie ASC
")->fetchAll();
?>

<div class="page-header">
  <div>
    <h1>Tableau de bord</h1>
    <div class="sub">Vue d'ensemble de l'activité Fibromed</div>
  </div>
</div>

<div class="kpi-grid">
  <div class="kpi-card">
    <div class="value"><?= $totalContacts ?></div>
    <div class="label">Contacts / prospects</div>
  </div>
  <div class="kpi-card accent-green">
    <div class="value"><?= $tauxConversion ?>%</div>
    <div class="label">Taux de conversion client (<?= $totalClients ?>/<?= $totalContacts ?>)</div>
  </div>
  <div class="kpi-card accent-warning">
    <div class="value"><?= $reparationsEnCours ?></div>
    <div class="label">Réparations en cours</div>
  </div>
  <div class="kpi-card">
    <div class="value"><?= formatMoney($caFacture) ?></div>
    <div class="label">CA facturé (hors annulé)</div>
  </div>
  <div class="kpi-card accent-green">
    <div class="value"><?= formatMoney($caEncaisse) ?></div>
    <div class="label">CA encaissé (payé)</div>
  </div>
  <div class="kpi-card accent-danger">
    <div class="value"><?= formatMoney($montantEnRetard) ?></div>
    <div class="label"><?= count($facturesEnRetard) ?> facture(s) en retard</div>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <h2>Répartition du pipeline</h2>
    <?php if (empty($repartitionStatuts)): ?>
      <div class="empty-state">Aucun contact pour le moment.</div>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Statut</th><th>Nombre</th></tr></thead>
          <tbody>
          <?php foreach ($repartitionStatuts as $r): ?>
            <tr>
              <td><span class="badge" style="background:<?= e($r['couleur']) ?>"><?= e($r['nom']) ?></span></td>
              <td><?= (int)$r['total'] ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>Tâches à faire (<?= count($tachesAFaire) ?>)</h2>
    <?php if (empty($tachesAFaire)): ?>
      <div class="empty-state">Aucune tâche à traiter aujourd'hui 🎉</div>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Contact</th><th>Type</th><th>Établissement</th><th>Date prévue</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($tachesAFaire as $t): ?>
            <tr>
              <td><a href="contact_view.php?id=<?= (int)$t['contact_id'] ?>"><?= e($t['prenom'] . ' ' . $t['nom']) ?></a><?php if ($t['titre']): ?><div class="sub" style="margin:0;"><?= e($t['titre']) ?></div><?php endif; ?></td>
              <td><span class="canal-tag"><?= e($t['type']) ?></span></td>
              <td><?= e($t['etablissement_nom'] ?? '—') ?></td>
              <td><?= $t['date_prevue'] < todayIso() ? '<span class="badge danger">' . formatDateFr($t['date_prevue']) . ' (en retard)</span>' : formatDateFr($t['date_prevue']) ?></td>
              <td><a href="contact_view.php?id=<?= (int)$t['contact_id'] ?>" class="btn btn-sm btn-secondary">Voir</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <h2>Factures en retard</h2>
    <?php if (empty($facturesEnRetard)): ?>
      <div class="empty-state">Aucune facture en retard.</div>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>N°</th><th>Établissement</th><th>Échéance</th><th>Montant</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($facturesEnRetard as $f): ?>
            <tr>
              <td><?= e($f['numero']) ?></td>
              <td><?= e($f['etablissement_nom'] ?? '—') ?></td>
              <td><span class="badge danger"><?= formatDateFr($f['date_echeance']) ?></span></td>
              <td><?= formatMoney($f['total_ttc']) ?></td>
              <td><a href="document_view.php?id=<?= (int)$f['id'] ?>" class="btn btn-sm btn-secondary">Voir</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>Garanties bientôt expirées (30 jours)</h2>
    <?php if (empty($garanties)): ?>
      <div class="empty-state">Aucune garantie n'expire dans les 30 prochains jours.</div>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Appareil</th><th>Établissement</th><th>Fin de garantie</th><th></th></tr></thead>
          <tbody>
          <?php foreach ($garanties as $g): ?>
            <tr>
              <td><?= e(trim(($g['marque'] ?? '') . ' ' . ($g['modele'] ?? ''))) ?></td>
              <td><?= e($g['etablissement_nom'] ?? '—') ?></td>
              <td><span class="badge warning"><?= formatDateFr($g['fin_garantie']) ?></span></td>
              <td><a href="reparation_form.php?id=<?= (int)$g['id'] ?>" class="btn btn-sm btn-secondary">Voir</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

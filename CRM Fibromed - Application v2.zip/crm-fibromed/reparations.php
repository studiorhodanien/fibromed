<?php
$pageTitle = 'Réparations';
$activeNav = 'reparations';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$filtreStatut = $_GET['statut'] ?? '';
$recherche = trim($_GET['q'] ?? '');

$where = [];
$params = [];
if ($filtreStatut !== '') { $where[] = 'r.statut = ?'; $params[] = $filtreStatut; }
if ($recherche !== '') {
    $where[] = '(r.marque LIKE ? OR r.modele LIKE ? OR r.numero_serie LIKE ?)';
    $like = '%' . $recherche . '%';
    $params[] = $like; $params[] = $like; $params[] = $like;
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "
    SELECT r.*, e.nom AS etablissement_nom,
           DATE_ADD(r.date_fin_reelle, INTERVAL r.garantie_mois MONTH) AS fin_garantie
    FROM reparations r
    LEFT JOIN etablissements e ON e.id = r.etablissement_id
    $whereSql
    ORDER BY r.date_reception DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reparations = $stmt->fetchAll();

$statutsListe = ['Reçu','En diagnostic','En réparation','Terminé','Restitué'];
?>

<div class="page-header">
  <div>
    <h1>Suivi des réparations</h1>
    <div class="sub"><?= count($reparations) ?> dossier(s)</div>
  </div>
  <a href="reparation_form.php" class="btn">+ Nouvelle réparation</a>
</div>

<form method="get" class="filters-bar card">
  <div class="form-row">
    <label>Recherche</label>
    <input type="text" name="q" value="<?= e($recherche) ?>" placeholder="Marque, modèle, n° série...">
  </div>
  <div class="form-row">
    <label>Statut</label>
    <select name="statut">
      <option value="">Tous</option>
      <?php foreach ($statutsListe as $s): ?>
        <option value="<?= e($s) ?>" <?= $filtreStatut === $s ? 'selected' : '' ?>><?= e($s) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button type="submit" class="btn btn-secondary">Filtrer</button>
  <a href="reparations.php" class="btn btn-secondary">Réinitialiser</a>
</form>

<?php if (empty($reparations)): ?>
  <div class="card empty-state">Aucune réparation enregistrée.</div>
<?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>Appareil</th><th>N° série</th><th>Établissement</th><th>Réception</th><th>Fin prévue</th><th>Statut</th><th>Garantie jusqu'au</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($reparations as $r): ?>
          <tr>
            <td><?= e(trim(($r['marque'] ?? '') . ' ' . ($r['modele'] ?? ''))) ?: '—' ?></td>
            <td><?= e($r['numero_serie'] ?: '—') ?></td>
            <td><?= e($r['etablissement_nom'] ?: '—') ?></td>
            <td><?= formatDateFr($r['date_reception']) ?></td>
            <td><?= formatDateFr($r['date_fin_prevue']) ?></td>
            <td>
              <?php
                if (in_array($r['statut'], ['Terminé', 'Restitué'], true)) {
                    $badgeClass = 'success';
                } elseif ($r['statut'] === 'En réparation') {
                    $badgeClass = 'warning';
                } else {
                    $badgeClass = '';
                }
              ?>
              <span class="badge <?= $badgeClass ?>"><?= e($r['statut']) ?></span>
            </td>
            <td><?= $r['fin_garantie'] ? formatDateFr($r['fin_garantie']) : '—' ?></td>
            <td><a href="reparation_form.php?id=<?= (int)$r['id'] ?>" class="btn btn-sm btn-secondary">Voir / Modifier</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

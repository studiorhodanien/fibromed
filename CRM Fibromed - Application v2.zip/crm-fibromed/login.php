<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    redirect('index.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if (attemptLogin($username, $password)) {
        redirect('index.php');
    } else {
        $error = 'Identifiant ou mot de passe incorrect.';
    }
}
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Connexion — CRM Fibromed</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-wrap">
  <div class="login-box">
    <div class="brand">FIBRO<span>MED</span></div>
    <div class="tagline">CRM — Gestion commerciale &amp; opérationnelle</div>
    <?php if ($error): ?><div class="flash error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" action="login.php">
      <?= csrfField() ?>
      <div class="form-row">
        <label for="username">Identifiant</label>
        <input type="text" id="username" name="username" required autofocus>
      </div>
      <div class="form-row">
        <label for="password">Mot de passe</label>
        <input type="password" id="password" name="password" required>
      </div>
      <button type="submit" class="btn">Se connecter</button>
    </form>
  </div>
</div>
</body>
</html>

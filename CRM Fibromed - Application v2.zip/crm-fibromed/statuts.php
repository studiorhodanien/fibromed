<?php
$pageTitle = 'Statuts du pipeline';
$activeNav = 'statuts';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $action = $_POST['action'] ?? '';

    if ($action === 'create') {
        $nom = trim($_POST['nom'] ?? '');
        $couleur = trim($_POST['couleur'] ?? '#1A2050');
        if ($nom !== '') {
            $maxOrdre = (int)$pdo->query('SELECT COALESCE(MAX(ordre),0) FROM statuts')->fetchColumn();
            $stmt = $pdo->prepare('INSERT INTO statuts (nom, couleur, ordre) VALUES (?, ?, ?)');
            $stmt->execute([$nom, $couleur, $maxOrdre + 1]);
            flash('success', 'Statut ajouté.');
        }
    }

    if ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $nom = trim($_POST['nom'] ?? '');
        $couleur = trim($_POST['couleur'] ?? '#1A2050');
        $ordre = (int)($_POST['ordre'] ?? 0);
        if ($id && $nom !== '') {
            $stmt = $pdo->prepare('UPDATE statuts SET nom = ?, couleur = ?, ordre = ? WHERE id = ?');
            $stmt->execute([$nom, $couleur, $ordre, $id]);
            flash('success', 'Statut mis à jour.');
        }
    }

    if ($action === 'toggle') {
        $id = (int)($_POST['id'] ?? 0);
        $stmt = $pdo->prepare('UPDATE statuts SET actif = 1 - actif WHERE id = ?');
        $stmt->execute([$id]);
        flash('success', 'Statut mis à jour.');
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        // On désactive plutôt que supprimer si des contacts l'utilisent encore, pour ne pas casser l'historique.
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM contacts WHERE statut_id = ?');
        $stmt->execute([$id]);
        if ((int)$stmt->fetchColumn() > 0) {
            $pdo->prepare('UPDATE statuts SET actif = 0 WHERE id = ?')->execute([$id]);
            flash('info', 'Ce statut est utilisé par des contacts : il a été désactivé plutôt que supprimé.');
        } else {
            $pdo->prepare('DELETE FROM statuts WHERE id = ?')->execute([$id]);
            flash('success', 'Statut supprimé.');
        }
    }

    redirect('statuts.php');
}

$statuts = getPDO()->query('SELECT * FROM statuts ORDER BY ordre ASC, id ASC')->fetchAll();
?>

<div class="page-header">
  <div>
    <h1>Statuts du pipeline commercial</h1>
    <div class="sub">Personnalisez les statuts utilisés pour suivre vos contacts.</div>
  </div>
</div>

<div class="card">
  <h2>Ajouter un statut</h2>
  <form method="post" class="filters-bar">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="create">
    <div class="form-row">
      <label>Nom</label>
      <input type="text" name="nom" required placeholder="Ex : Client sous contrat">
    </div>
    <div class="form-row">
      <label>Couleur</label>
      <input type="color" name="couleur" value="#1A2050" style="height:40px;">
    </div>
    <button type="submit" class="btn">Ajouter</button>
  </form>
</div>

<div class="card">
  <h2>Statuts existants</h2>
  <?php foreach ($statuts as $s): ?>
    <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:12px 0;border-bottom:1px solid var(--grey-border);">
      <form method="post" class="btn-group" style="align-items:center;flex:1;flex-wrap:wrap;">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="update">
        <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
        <input type="number" name="ordre" value="<?= (int)$s['ordre'] ?>" style="width:60px" title="Ordre d'affichage">
        <input type="text" name="nom" value="<?= e($s['nom']) ?>" style="max-width:220px">
        <input type="color" name="couleur" value="<?= e($s['couleur']) ?>" style="height:38px;width:50px;padding:2px;">
        <button type="submit" class="btn btn-sm btn-secondary">Enregistrer</button>
      </form>
      <?= $s['actif'] ? '<span class="badge success">Actif</span>' : '<span class="badge grey">Inactif</span>' ?>
      <form method="post" style="display:inline">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="toggle">
        <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
        <button type="submit" class="btn btn-sm btn-secondary"><?= $s['actif'] ? 'Désactiver' : 'Activer' ?></button>
      </form>
      <form method="post" style="display:inline" onsubmit="return confirm('Supprimer ce statut ?');">
        <?= csrfField() ?>
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
        <button type="submit" class="btn btn-sm btn-danger">Supprimer</button>
      </form>
    </div>
  <?php endforeach; ?>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

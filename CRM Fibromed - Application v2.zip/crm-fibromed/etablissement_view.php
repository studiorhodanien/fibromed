<?php
$pageTitle = 'Fiche établissement';
$activeNav = 'etablissements';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM etablissements WHERE id = ?');
$stmt->execute([$id]);
$etab = $stmt->fetch();
if (!$etab) {
    flash('error', 'Établissement introuvable.');
    redirect('etablissements.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    csrfCheck();
    $stmt = $pdo->prepare('DELETE FROM etablissements WHERE id = ?');
    $stmt->execute([$id]);
    flash('success', 'Établissement supprimé.');
    redirect('etablissements.php');
}

$stmt = $pdo->prepare('SELECT c.*, s.nom AS statut_nom, s.couleur AS statut_couleur FROM contacts c LEFT JOIN statuts s ON s.id = c.statut_id WHERE c.etablissement_id = ? ORDER BY c.nom ASC');
$stmt->execute([$id]);
$contacts = $stmt->fetchAll();

$stmt = $pdo->prepare('SELECT * FROM reparations WHERE etablissement_id = ? ORDER BY date_reception DESC');
$stmt->execute([$id]);
$reparations = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM documents WHERE etablissement_id = ? AND type IN ('devis','facture') ORDER BY date_emission DESC");
$stmt->execute([$id]);
$documents = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM documents WHERE etablissement_id = ? AND type = 'bon_livraison' ORDER BY date_emission DESC");
$stmt->execute([$id]);
$bonsLivraison = $stmt->fetchAll();
?>

<div class="page-header">
  <div>
    <h1><?= e($etab['nom']) ?></h1>
    <div class="sub"><?= e($etab['secteur'] ?: '') ?><?= $etab['ville'] ? ' — ' . e($etab['ville']) : '' ?></div>
  </div>
  <div class="btn-group">
    <a href="etablissement_form.php?id=<?= $id ?>" class="btn btn-secondary">Modifier</a>
    <form method="post" style="display:inline" onsubmit="return confirm('Supprimer définitivement cet établissement ?');">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="delete">
      <button type="submit" class="btn btn-danger">Supprimer</button>
    </form>
  </div>
</div>

<div class="card">
  <h2>Informations</h2>
  <table>
    <tr><td>Adresse</td><td><?= e($etab['adresse'] ?: '—') ?></td></tr>
    <tr><td>Ville / Pays</td><td><?= e($etab['ville'] ?: '—') ?><?= $etab['pays'] ? ' — ' . e($etab['pays']) : '' ?></td></tr>
    <tr><td>Téléphone</td><td><?= e($etab['telephone'] ?: '—') ?></td></tr>
    <tr><td>Email</td><td><?= e($etab['email'] ?: '—') ?></td></tr>
  </table>
  <?php if ($etab['notes']): ?><p style="white-space:pre-wrap;margin-top:14px;"><?= e($etab['notes']) ?></p><?php endif; ?>
</div>

<div class="card">
  <h2>Contacts rattachés (<?= count($contacts) ?>)</h2>
  <?php if (empty($contacts)): ?>
    <div class="empty-state">Aucun contact rattaché. <a href="contact_form.php">Ajouter un contact</a></div>
  <?php else: ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Nom</th><th>Poste</th><th>Statut</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($contacts as $c): ?>
          <tr>
            <td><a href="contact_view.php?id=<?= (int)$c['id'] ?>"><?= e($c['prenom'] . ' ' . $c['nom']) ?></a></td>
            <td><?= e($c['poste'] ?: '—') ?></td>
            <td><?= $c['statut_nom'] ? '<span class="badge" style="background:' . e($c['statut_couleur']) . '">' . e($c['statut_nom']) . '</span>' : '—' ?></td>
            <td><a href="contact_view.php?id=<?= (int)$c['id'] ?>" class="btn btn-sm btn-secondary">Voir</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>

<div class="grid-2">
  <div class="card">
    <h2>Réparations (<?= count($reparations) ?>)</h2>
    <?php if (empty($reparations)): ?>
      <div class="empty-state">Aucune réparation enregistrée.</div>
    <?php else: ?>
      <?php foreach ($reparations as $r): ?>
        <div style="padding:8px 0;border-bottom:1px solid var(--grey-border);font-size:13.5px;">
          <a href="reparation_form.php?id=<?= (int)$r['id'] ?>"><?= e($r['marque'] . ' ' . $r['modele']) ?></a>
          — <?= e($r['statut']) ?> — reçu le <?= formatDateFr($r['date_reception']) ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
  <div class="card">
    <h2>Devis / Factures (<?= count($documents) ?>)</h2>
    <?php if (empty($documents)): ?>
      <div class="empty-state">Aucun document.</div>
    <?php else: ?>
      <?php foreach ($documents as $d): ?>
        <div style="padding:8px 0;border-bottom:1px solid var(--grey-border);font-size:13.5px;">
          <a href="document_view.php?id=<?= (int)$d['id'] ?>"><?= e($d['numero']) ?></a>
          — <?= ucfirst(e($d['statut'])) ?> — <?= formatMoney($d['total_ttc']) ?>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($bonsLivraison)): ?>
<div class="card">
  <h2>Bons de livraison (<?= count($bonsLivraison) ?>)</h2>
  <?php foreach ($bonsLivraison as $bl): ?>
    <div style="padding:8px 0;border-bottom:1px solid var(--grey-border);font-size:13.5px;">
      <a href="bon_livraison_view.php?id=<?= (int)$bl['id'] ?>"><?= e($bl['numero']) ?></a>
      — livré le <?= formatDateFr($bl['date_emission']) ?>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

<?php
$pageTitle = 'Bon de livraison';
$activeNav = 'documents';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$factureId = isset($_GET['facture_id']) ? (int)$_GET['facture_id'] : null;

$doc = [
    'etablissement_id' => '', 'contact_id' => '',
    'date_emission' => todayIso(), 'statut' => 'envoyé', 'notes' => '',
    'facture_source_id' => $factureId ?: null,
];
$lignes = [];
$factureNumero = null;

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM documents WHERE id = ? AND type = 'bon_livraison'");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) {
        flash('error', 'Bon de livraison introuvable.');
        redirect('documents.php');
    }
    $doc = $found;
    $stmt = $pdo->prepare('SELECT * FROM bon_livraison_lignes WHERE document_id = ? ORDER BY ordre ASC, id ASC');
    $stmt->execute([$id]);
    $lignes = $stmt->fetchAll();
} elseif ($factureId) {
    // Pré-remplissage depuis une facture existante.
    $stmt = $pdo->prepare("SELECT * FROM documents WHERE id = ? AND type = 'facture'");
    $stmt->execute([$factureId]);
    $facture = $stmt->fetch();
    if ($facture) {
        $doc['etablissement_id'] = $facture['etablissement_id'];
        $doc['contact_id'] = $facture['contact_id'];
        $factureNumero = $facture['numero'];
        $stmt = $pdo->prepare('SELECT * FROM document_lignes WHERE document_id = ? ORDER BY ordre ASC, id ASC');
        $stmt->execute([$factureId]);
        foreach ($stmt->fetchAll() as $l) {
            $lignes[] = ['designation' => $l['designation'], 'marque' => '', 'modele' => '', 'numero_serie' => '', 'quantite' => $l['quantite']];
        }
    }
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $doc['etablissement_id'] = $_POST['etablissement_id'] ?: null;
    $doc['contact_id'] = $_POST['contact_id'] ?: null;
    $doc['date_emission'] = $_POST['date_emission'] ?: todayIso();
    $doc['statut'] = $_POST['statut'] ?? 'envoyé';
    $doc['notes'] = trim($_POST['notes'] ?? '');
    $doc['facture_source_id'] = $_POST['facture_source_id'] ?: null;

    $lignesPost = $_POST['lignes'] ?? [];
    $lignes = [];
    $ordre = 0;
    foreach ($lignesPost as $l) {
        $designation = trim($l['designation'] ?? '');
        $marque = trim($l['marque'] ?? '');
        $modele = trim($l['modele'] ?? '');
        $numeroSerie = trim($l['numero_serie'] ?? '');
        $quantite = (float)($l['quantite'] ?? 0);
        if ($designation === '' && $marque === '' && $modele === '' && $numeroSerie === '' && $quantite == 0) {
            continue;
        }
        $lignes[] = ['designation' => $designation, 'marque' => $marque, 'modele' => $modele, 'numero_serie' => $numeroSerie, 'quantite' => $quantite ?: 1, 'ordre' => $ordre++];
    }

    if (empty($doc['etablissement_id'])) {
        $errors[] = "Merci de sélectionner un établissement.";
    }
    if (empty($lignes)) {
        $errors[] = "Ajoutez au moins un élément de matériel livré.";
    }

    if (empty($errors)) {
        if ($id) {
            $stmt = $pdo->prepare('UPDATE documents SET etablissement_id=?, contact_id=?, date_emission=?, statut=?, notes=? WHERE id=?');
            $stmt->execute([$doc['etablissement_id'], $doc['contact_id'], $doc['date_emission'], $doc['statut'], $doc['notes'], $id]);
            $pdo->prepare('DELETE FROM bon_livraison_lignes WHERE document_id = ?')->execute([$id]);
            $stmtLigne = $pdo->prepare('INSERT INTO bon_livraison_lignes (document_id, designation, marque, modele, numero_serie, quantite, ordre) VALUES (?,?,?,?,?,?,?)');
            foreach ($lignes as $l) {
                $stmtLigne->execute([$id, $l['designation'], $l['marque'], $l['modele'], $l['numero_serie'], $l['quantite'], $l['ordre']]);
            }
            flash('success', 'Bon de livraison mis à jour.');
            redirect('bon_livraison_view.php?id=' . $id);
        } else {
            $numero = generateDocumentNumber('bon_livraison');
            $stmt = $pdo->prepare('INSERT INTO documents (type, numero, etablissement_id, contact_id, date_emission, statut, notes, facture_source_id) VALUES (\'bon_livraison\',?,?,?,?,?,?,?)');
            $stmt->execute([$numero, $doc['etablissement_id'], $doc['contact_id'], $doc['date_emission'], $doc['statut'], $doc['notes'], $doc['facture_source_id']]);
            $newId = $pdo->lastInsertId();
            $stmtLigne = $pdo->prepare('INSERT INTO bon_livraison_lignes (document_id, designation, marque, modele, numero_serie, quantite, ordre) VALUES (?,?,?,?,?,?,?)');
            foreach ($lignes as $l) {
                $stmtLigne->execute([$newId, $l['designation'], $l['marque'], $l['modele'], $l['numero_serie'], $l['quantite'], $l['ordre']]);
            }
            if ($doc['facture_source_id']) {
                $pdo->prepare('UPDATE documents SET bon_livraison_id = ? WHERE id = ?')->execute([$newId, $doc['facture_source_id']]);
            }
            flash('success', "Bon de livraison $numero créé.");
            redirect('bon_livraison_view.php?id=' . $newId);
        }
    }
}

$etablissements = getEtablissementsList();
$stmt = $pdo->query('SELECT id, prenom, nom, etablissement_id FROM contacts ORDER BY nom ASC');
$allContacts = $stmt->fetchAll();

if (empty($lignes)) {
    $lignes = [['designation' => '', 'marque' => '', 'modele' => '', 'numero_serie' => '', 'quantite' => 1]];
}
?>

<div class="page-header">
  <h1><?= $id ? 'Modifier le bon de livraison' : 'Nouveau bon de livraison' ?></h1>
</div>

<?php if ($factureNumero): ?>
  <div class="flash info">Pré-rempli à partir de la facture <strong><?= e($factureNumero) ?></strong>. Complétez marque / modèle / n° de série pour chaque appareil livré.</div>
<?php endif; ?>

<?php foreach ($errors as $err): ?><div class="flash error"><?= e($err) ?></div><?php endforeach; ?>

<div class="card">
  <form method="post" action="bon_livraison_form.php<?= $id ? '?id=' . $id : '' ?>">
    <?= csrfField() ?>
    <input type="hidden" name="facture_source_id" value="<?= e((string)($doc['facture_source_id'] ?? '')) ?>">
    <div class="form-grid">
      <div class="form-row">
        <label>Établissement *</label>
        <select name="etablissement_id" required>
          <option value="">— Choisir —</option>
          <?php foreach ($etablissements as $e): ?>
            <option value="<?= (int)$e['id'] ?>" <?= (string)$doc['etablissement_id'] === (string)$e['id'] ? 'selected' : '' ?>><?= e($e['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Contact (optionnel)</label>
        <select name="contact_id">
          <option value="">— Aucun —</option>
          <?php foreach ($allContacts as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= (string)$doc['contact_id'] === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['prenom'] . ' ' . $c['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Date de livraison</label>
        <input type="date" name="date_emission" value="<?= e($doc['date_emission']) ?>">
      </div>
      <div class="form-row">
        <label>Statut</label>
        <select name="statut">
          <option value="brouillon" <?= $doc['statut'] === 'brouillon' ? 'selected' : '' ?>>Brouillon</option>
          <option value="envoyé" <?= $doc['statut'] === 'envoyé' ? 'selected' : '' ?>>Finalisé / remis au client</option>
        </select>
      </div>
    </div>

    <h2 style="margin-top:10px;">Matériel livré</h2>
    <div class="table-wrap">
      <table id="bl-lignes-table">
        <thead><tr><th>Désignation</th><th>Marque</th><th>Modèle</th><th>N° de série</th><th>Qté</th><th></th></tr></thead>
        <tbody id="bl-lignes-body">
          <?php foreach ($lignes as $i => $l): ?>
            <tr>
              <td><input type="text" name="lignes[<?= $i ?>][designation]" value="<?= e($l['designation']) ?>" placeholder="Ex : Endoscope souple"></td>
              <td><input type="text" name="lignes[<?= $i ?>][marque]" value="<?= e($l['marque'] ?? '') ?>" placeholder="Ex : Olympus"></td>
              <td><input type="text" name="lignes[<?= $i ?>][modele]" value="<?= e($l['modele'] ?? '') ?>" placeholder="Ex : GIF-H190"></td>
              <td><input type="text" name="lignes[<?= $i ?>][numero_serie]" value="<?= e($l['numero_serie'] ?? '') ?>" placeholder="N° de série"></td>
              <td style="width:80px"><input type="number" step="0.01" min="0" name="lignes[<?= $i ?>][quantite]" value="<?= e((string)$l['quantite']) ?>"></td>
              <td style="width:40px"><button type="button" class="btn btn-sm btn-danger remove-bl-ligne">✕</button></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <button type="button" id="add-bl-ligne-btn" class="btn btn-sm btn-secondary" style="margin-top:10px;">+ Ajouter un élément</button>

    <div class="form-row" style="margin-top:16px;">
      <label>Notes (visibles sur le document)</label>
      <textarea name="notes"><?= e($doc['notes']) ?></textarea>
    </div>

    <div class="form-actions">
      <button type="submit" class="btn">Enregistrer</button>
      <a href="<?= $id ? 'bon_livraison_view.php?id=' . $id : 'documents.php' ?>" class="btn btn-secondary">Annuler</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

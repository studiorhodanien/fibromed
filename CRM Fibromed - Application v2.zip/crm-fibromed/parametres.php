<?php
$pageTitle = 'Paramètres';
$activeNav = 'parametres';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $action = $_POST['action'] ?? '';

    if ($action === 'save_settings') {
        $fields = ['raison_sociale', 'rc', 'tribunal_rc', 'if_fiscal', 'ice', 'adresse', 'telephone', 'email', 'taux_tva', 'prefixe_devis', 'prefixe_facture', 'prefixe_bon_livraison', 'email_alertes', 'devise', 'gerant_nom', 'gerant_telephone', 'gerant_email'];
        foreach ($fields as $f) {
            setSetting($f, trim($_POST[$f] ?? ''));
        }
        setSetting('clause_juridique', trim($_POST['clause_juridique'] ?? ''));
        flash('success', 'Paramètres enregistrés.');
        redirect('parametres.php');
    }

    if ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        $new2 = $_POST['new_password2'] ?? '';

        $stmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ?');
        $stmt->execute([$user['id']]);
        $row = $stmt->fetch();

        if (!$row || !password_verify($current, $row['password_hash'])) {
            flash('error', 'Mot de passe actuel incorrect.');
        } elseif (strlen($new) < 8) {
            flash('error', 'Le nouveau mot de passe doit contenir au moins 8 caractères.');
        } elseif ($new !== $new2) {
            flash('error', 'Les deux mots de passe ne correspondent pas.');
        } else {
            $stmt = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
            $stmt->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
            flash('success', 'Mot de passe mis à jour.');
        }
        redirect('parametres.php');
    }
}

$settings = getAllSettings();
?>

<div class="page-header">
  <h1>Paramètres</h1>
</div>

<div class="card">
  <h2>Informations légales de l'entreprise</h2>
  <p class="sub" style="margin-top:-8px;margin-bottom:16px;">Ces informations apparaissent sur tous les devis et factures générés.</p>
  <form method="post">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="save_settings">
    <div class="form-grid">
      <div class="form-row">
        <label>Raison sociale</label>
        <input type="text" name="raison_sociale" value="<?= e($settings['raison_sociale'] ?? '') ?>">
      </div>
      <div class="form-row">
        <label>RC (Registre du Commerce)</label>
        <input type="text" name="rc" value="<?= e($settings['rc'] ?? '') ?>">
      </div>
      <div class="form-row">
        <label>Tribunal du RC</label>
        <input type="text" name="tribunal_rc" value="<?= e($settings['tribunal_rc'] ?? '') ?>">
      </div>
      <div class="form-row">
        <label>Identifiant Fiscal (IF)</label>
        <input type="text" name="if_fiscal" value="<?= e($settings['if_fiscal'] ?? '') ?>">
      </div>
      <div class="form-row">
        <label>ICE</label>
        <input type="text" name="ice" value="<?= e($settings['ice'] ?? '') ?>">
      </div>
      <div class="form-row">
        <label>Taux de TVA par défaut (%)</label>
        <input type="number" step="0.01" name="taux_tva" value="<?= e($settings['taux_tva'] ?? '20') ?>">
      </div>
      <div class="form-row">
        <label>Téléphone</label>
        <input type="text" name="telephone" value="<?= e($settings['telephone'] ?? '') ?>">
      </div>
      <div class="form-row">
        <label>Email de contact</label>
        <input type="email" name="email" value="<?= e($settings['email'] ?? '') ?>">
      </div>
      <div class="form-row">
        <label>Préfixe des devis</label>
        <input type="text" name="prefixe_devis" value="<?= e($settings['prefixe_devis'] ?? 'DEV') ?>">
      </div>
      <div class="form-row">
        <label>Préfixe des factures</label>
        <input type="text" name="prefixe_facture" value="<?= e($settings['prefixe_facture'] ?? 'FACT') ?>">
      </div>
      <div class="form-row">
        <label>Préfixe des bons de livraison</label>
        <input type="text" name="prefixe_bon_livraison" value="<?= e($settings['prefixe_bon_livraison'] ?? 'BL') ?>">
      </div>
      <div class="form-row">
        <label>Devise</label>
        <input type="text" name="devise" value="<?= e($settings['devise'] ?? 'MAD') ?>">
      </div>
      <div class="form-row">
        <label>Email pour les alertes automatiques</label>
        <input type="email" name="email_alertes" value="<?= e($settings['email_alertes'] ?? '') ?>" placeholder="aymen.habib@fibromed.ma">
      </div>
    </div>
    <div class="form-row">
      <label>Adresse du siège social</label>
      <input type="text" name="adresse" value="<?= e($settings['adresse'] ?? '') ?>">
    </div>

    <h2 style="margin-top:24px;">Gérant (affiché sur les devis)</h2>
    <div class="form-grid">
      <div class="form-row">
        <label>Nom du gérant</label>
        <input type="text" name="gerant_nom" value="<?= e($settings['gerant_nom'] ?? 'Aymen Habibellah') ?>">
      </div>
      <div class="form-row">
        <label>Téléphone du gérant</label>
        <input type="text" name="gerant_telephone" value="<?= e($settings['gerant_telephone'] ?? '') ?>">
      </div>
      <div class="form-row">
        <label>Email du gérant</label>
        <input type="email" name="gerant_email" value="<?= e($settings['gerant_email'] ?? '') ?>">
      </div>
    </div>
    <p class="sub" style="margin-top:-6px;">Ces coordonnées apparaissent en bas de tous les devis et factures générés.</p>

    <h2 style="margin-top:24px;">Clause juridique (devis)</h2>
    <div class="form-row">
      <label>Texte affiché automatiquement sur tous les devis</label>
      <textarea name="clause_juridique" rows="4"><?= e($settings['clause_juridique'] ?? '') ?></textarea>
    </div>

    <div class="form-actions">
      <button type="submit" class="btn">Enregistrer</button>
    </div>
  </form>
</div>

<div class="card">
  <h2>Changer mon mot de passe</h2>
  <form method="post" style="max-width:400px;">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="change_password">
    <div class="form-row">
      <label>Mot de passe actuel</label>
      <input type="password" name="current_password" required>
    </div>
    <div class="form-row">
      <label>Nouveau mot de passe</label>
      <input type="password" name="new_password" required minlength="8">
    </div>
    <div class="form-row">
      <label>Confirmer le nouveau mot de passe</label>
      <input type="password" name="new_password2" required minlength="8">
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">Mettre à jour</button>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

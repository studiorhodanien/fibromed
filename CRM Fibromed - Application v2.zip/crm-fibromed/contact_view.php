<?php
$pageTitle = 'Fiche contact';
$activeNav = 'contacts';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare('
    SELECT c.*, e.nom AS etablissement_nom, s.nom AS statut_nom, s.couleur AS statut_couleur
    FROM contacts c
    LEFT JOIN etablissements e ON e.id = c.etablissement_id
    LEFT JOIN statuts s ON s.id = c.statut_id
    WHERE c.id = ?
');
$stmt->execute([$id]);
$contact = $stmt->fetch();
if (!$contact) {
    flash('error', 'Contact introuvable.');
    redirect('contacts.php');
}

// --- Actions POST ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $action = $_POST['action'] ?? '';

    if ($action === 'add_interaction') {
        $canal = $_POST['canal'] ?? '';
        $date = $_POST['date_interaction'] ?? todayIso();
        $note = trim($_POST['note'] ?? '');
        if (in_array($canal, TACHES_TYPES, true)) {
            $stmt = $pdo->prepare('INSERT INTO interactions (contact_id, canal, date_interaction, note) VALUES (?,?,?,?)');
            $stmt->execute([$id, $canal, $date, $note]);
            flash('success', 'Interaction ajoutée à l\'historique.');
        }
        redirect('contact_view.php?id=' . $id);
    }

    if ($action === 'add_tache') {
        $type = $_POST['type'] ?? '';
        $titre = trim($_POST['titre'] ?? '');
        $datePrevue = $_POST['date_prevue'] ?? '';
        $note = trim($_POST['note'] ?? '');
        if (in_array($type, TACHES_TYPES, true) && $datePrevue !== '') {
            $stmt = $pdo->prepare('INSERT INTO taches (contact_id, type, titre, date_prevue, note) VALUES (?,?,?,?,?)');
            $stmt->execute([$id, $type, $titre !== '' ? $titre : null, $datePrevue, $note]);
            flash('success', 'Tâche programmée.');
        } else {
            flash('error', 'Merci de choisir un type et une date pour la tâche.');
        }
        redirect('contact_view.php?id=' . $id);
    }

    if ($action === 'complete_tache') {
        $tacheId = (int)($_POST['tache_id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE taches SET statut='fait', completed_at=NOW() WHERE id = ? AND contact_id = ?");
        $stmt->execute([$tacheId, $id]);
        flash('success', 'Tâche marquée comme faite.');
        redirect('contact_view.php?id=' . $id);
    }

    if ($action === 'reopen_tache') {
        $tacheId = (int)($_POST['tache_id'] ?? 0);
        $stmt = $pdo->prepare("UPDATE taches SET statut='a_faire', completed_at=NULL WHERE id = ? AND contact_id = ?");
        $stmt->execute([$tacheId, $id]);
        flash('success', 'Tâche réouverte.');
        redirect('contact_view.php?id=' . $id);
    }

    if ($action === 'delete_tache') {
        $tacheId = (int)($_POST['tache_id'] ?? 0);
        $stmt = $pdo->prepare('DELETE FROM taches WHERE id = ? AND contact_id = ?');
        $stmt->execute([$tacheId, $id]);
        flash('success', 'Tâche supprimée.');
        redirect('contact_view.php?id=' . $id);
    }

    if ($action === 'update_statut') {
        $statutId = $_POST['statut_id'] ?: null;
        $stmt = $pdo->prepare('UPDATE contacts SET statut_id = ? WHERE id = ?');
        $stmt->execute([$statutId, $id]);
        flash('success', 'Statut mis à jour.');
        redirect('contact_view.php?id=' . $id);
    }

    if ($action === 'delete') {
        $stmt = $pdo->prepare('DELETE FROM contacts WHERE id = ?');
        $stmt->execute([$id]);
        flash('success', 'Contact supprimé.');
        redirect('contacts.php');
    }
}

$stmt = $pdo->prepare('SELECT * FROM interactions WHERE contact_id = ? ORDER BY date_interaction DESC, id DESC');
$stmt->execute([$id]);
$interactions = $stmt->fetchAll();

$stmt = $pdo->prepare('SELECT * FROM taches WHERE contact_id = ? ORDER BY date_prevue ASC, id ASC');
$stmt->execute([$id]);
$toutesTaches = $stmt->fetchAll();
$tachesOuvertes = array_values(array_filter($toutesTaches, fn($t) => $t['statut'] === 'a_faire'));
$tachesFaites = array_values(array_filter($toutesTaches, fn($t) => $t['statut'] === 'fait'));

// Timeline fusionnée : interactions loguées + tâches terminées, triée du plus récent au plus ancien.
$timeline = [];
foreach ($interactions as $i) {
    $timeline[] = ['date' => $i['date_interaction'], 'sort' => $i['date_interaction'] . ' ' . str_pad((string)$i['id'], 10, '0', STR_PAD_LEFT), 'type' => $i['canal'], 'note' => $i['note'], 'kind' => 'interaction'];
}
foreach ($tachesFaites as $t) {
    $dateAffichee = $t['completed_at'] ? date('Y-m-d', strtotime($t['completed_at'])) : $t['date_prevue'];
    $timeline[] = ['date' => $dateAffichee, 'sort' => $dateAffichee . ' ' . str_pad((string)$t['id'], 10, '0', STR_PAD_LEFT), 'type' => $t['type'], 'note' => trim(($t['titre'] ?? '') . ($t['note'] ? ' — ' . $t['note'] : '')), 'kind' => 'tache'];
}
usort($timeline, fn($a, $b) => strcmp($b['sort'], $a['sort']));

$statuts = getStatuts();

// Documents et réparations liés à cet établissement (contexte utile)
$documentsLies = [];
$reparationsLiees = [];
if ($contact['etablissement_id']) {
    $stmt = $pdo->prepare("SELECT * FROM documents WHERE etablissement_id = ? AND type IN ('devis','facture') ORDER BY date_emission DESC LIMIT 5");
    $stmt->execute([$contact['etablissement_id']]);
    $documentsLies = $stmt->fetchAll();

    $stmt = $pdo->prepare('SELECT * FROM reparations WHERE etablissement_id = ? ORDER BY date_reception DESC LIMIT 5');
    $stmt->execute([$contact['etablissement_id']]);
    $reparationsLiees = $stmt->fetchAll();
}

$todayIso = todayIso();
?>

<div class="page-header">
  <div>
    <h1><?= e($contact['prenom'] . ' ' . $contact['nom']) ?></h1>
    <div class="sub"><?= e($contact['poste'] ?? '') ?><?= $contact['etablissement_nom'] ? ' — ' . e($contact['etablissement_nom']) : '' ?></div>
  </div>
  <div class="btn-group">
    <a href="contact_form.php?id=<?= $id ?>" class="btn btn-secondary">Modifier</a>
    <form method="post" style="display:inline" onsubmit="return confirm('Supprimer définitivement ce contact ?');">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="delete">
      <button type="submit" class="btn btn-danger">Supprimer</button>
    </form>
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <h2>Informations</h2>
    <table>
      <tr><td>Segment</td><td><?= $contact['segment'] ? e($contact['segment']) : '—' ?></td></tr>
      <tr><td>Ville / Pays</td><td><?= e($contact['ville'] ?: '—') ?><?= $contact['pays'] ? ' — ' . e($contact['pays']) : '' ?></td></tr>
      <tr><td>Téléphone / WhatsApp</td><td><?= e($contact['telephone'] ?: '—') ?></td></tr>
      <tr><td>Email</td><td><?= e($contact['email'] ?: '—') ?></td></tr>
      <tr><td>LinkedIn</td><td><?= $contact['linkedin_url'] ? '<a href="' . e($contact['linkedin_url']) . '" target="_blank" rel="noopener">Voir le profil</a>' : '—' ?></td></tr>
      <tr><td>Établissement</td><td><?= $contact['etablissement_id'] ? '<a href="etablissement_view.php?id=' . (int)$contact['etablissement_id'] . '">' . e($contact['etablissement_nom']) . '</a>' : '—' ?></td></tr>
    </table>
    <?php if ($contact['notes']): ?>
      <h2 style="margin-top:18px;">Notes</h2>
      <p style="white-space:pre-wrap;"><?= e($contact['notes']) ?></p>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>Statut du pipeline</h2>
    <form method="post" class="form-row">
      <?= csrfField() ?>
      <input type="hidden" name="action" value="update_statut">
      <select name="statut_id" onchange="this.form.submit()">
        <option value="">— Aucun —</option>
        <?php foreach ($statuts as $s): ?>
          <option value="<?= (int)$s['id'] ?>" <?= (string)$contact['statut_id'] === (string)$s['id'] ? 'selected' : '' ?>><?= e($s['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </form>

    <?php if (!empty($documentsLies) || !empty($reparationsLiees)): ?>
      <h2 style="margin-top:20px;">Lié à l'établissement</h2>
      <?php foreach ($reparationsLiees as $r): ?>
        <div style="font-size:13.5px;margin-bottom:6px;">🔧 <a href="reparation_form.php?id=<?= (int)$r['id'] ?>"><?= e($r['marque'] . ' ' . $r['modele']) ?></a> — <?= e($r['statut']) ?></div>
      <?php endforeach; ?>
      <?php foreach ($documentsLies as $d): ?>
        <div style="font-size:13.5px;margin-bottom:6px;">📄 <a href="document_view.php?id=<?= (int)$d['id'] ?>"><?= e($d['numero']) ?></a> — <?= formatMoney($d['total_ttc']) ?></div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>

<div class="card">
  <h2>Tâches à venir (<?= count($tachesOuvertes) ?>)</h2>
  <p class="sub" style="margin-top:-8px;margin-bottom:14px;">Programmez vous-même vos relances : appel, réunion, mail, message, LinkedIn...</p>

  <form method="post" class="filters-bar" style="margin-bottom:20px;">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="add_tache">
    <div class="form-row">
      <label>Type</label>
      <select name="type" required>
        <?php foreach (TACHES_TYPES as $t): ?>
          <option value="<?= e($t) ?>"><?= e($t) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-row" style="flex:1;min-width:180px;">
      <label>Objet (optionnel)</label>
      <input type="text" name="titre" placeholder="Ex : Relancer sur le devis">
    </div>
    <div class="form-row">
      <label>Date prévue</label>
      <input type="date" name="date_prevue" value="<?= e($todayIso) ?>" required>
    </div>
    <div class="form-row" style="flex:1;min-width:180px;">
      <label>Note</label>
      <input type="text" name="note" placeholder="Détails...">
    </div>
    <button type="submit" class="btn">Programmer la tâche</button>
  </form>

  <?php if (empty($tachesOuvertes)): ?>
    <div class="empty-state">Aucune tâche programmée pour l'instant.</div>
  <?php else: ?>
    <?php foreach ($tachesOuvertes as $t): ?>
      <div class="tache-row <?= $t['date_prevue'] < $todayIso ? 'en-retard' : '' ?>">
        <div>
          <span class="canal-tag"><?= e($t['type']) ?></span>
          <?php if ($t['titre']): ?><strong><?= e($t['titre']) ?></strong><?php endif; ?>
          <span class="meta"> — <?= $t['date_prevue'] < $todayIso ? '<span class="badge danger">' . formatDateFr($t['date_prevue']) . ' (en retard)</span>' : formatDateFr($t['date_prevue']) ?></span>
          <?php if ($t['note']): ?><div class="meta"><?= e($t['note']) ?></div><?php endif; ?>
        </div>
        <div class="btn-group">
          <form method="post" style="display:inline">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="complete_tache">
            <input type="hidden" name="tache_id" value="<?= (int)$t['id'] ?>">
            <button type="submit" class="btn btn-sm">✓ Fait</button>
          </form>
          <form method="post" style="display:inline" onsubmit="return confirm('Supprimer cette tâche ?');">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="delete_tache">
            <input type="hidden" name="tache_id" value="<?= (int)$t['id'] ?>">
            <button type="submit" class="btn btn-sm btn-danger">✕</button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<div class="card">
  <h2>Historique des échanges</h2>
  <form method="post" class="filters-bar" style="margin-bottom:20px;">
    <?= csrfField() ?>
    <input type="hidden" name="action" value="add_interaction">
    <div class="form-row">
      <label>Nature</label>
      <select name="canal" required>
        <?php foreach (TACHES_TYPES as $t): ?>
          <option value="<?= e($t) ?>"><?= e($t) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-row">
      <label>Date</label>
      <input type="date" name="date_interaction" value="<?= todayIso() ?>">
    </div>
    <div class="form-row" style="flex:1;min-width:220px;">
      <label>Note</label>
      <input type="text" name="note" placeholder="Résumé de l'échange...">
    </div>
    <button type="submit" class="btn">Ajouter</button>
  </form>

  <?php if (empty($timeline)): ?>
    <div class="empty-state">Aucun échange enregistré pour l'instant.</div>
  <?php else: ?>
    <ul class="timeline">
      <?php foreach ($timeline as $item): ?>
        <li>
          <div class="meta">
            <span class="canal-tag"><?= e($item['type']) ?></span>
            <?= $item['kind'] === 'tache' ? '<span class="badge success" style="margin-left:4px;">tâche faite</span>' : '' ?>
            — <?= formatDateFr($item['date']) ?>
          </div>
          <?php if ($item['note']): ?><div><?= e($item['note']) ?></div><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

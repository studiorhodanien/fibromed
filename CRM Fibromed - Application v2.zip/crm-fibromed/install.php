<?php
/**
 * Script d'installation — à utiliser UNE SEULE FOIS après avoir rempli config/config.php.
 * 1) Crée automatiquement les tables de la base de données (à partir de sql/schema.sql)
 *    si elles n'existent pas encore.
 * 2) Crée le compte administrateur (Aymen) via un petit formulaire.
 *
 * Une fois un compte créé, ce script se bloque automatiquement (sécurité) :
 * il est alors conseillé de le supprimer du serveur.
 */
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pdo = getPDO();

// Vérifie si les tables existent déjà, sinon exécute le schéma.
function tablesExist(PDO $pdo): bool
{
    try {
        $pdo->query('SELECT 1 FROM users LIMIT 1');
        return true;
    } catch (Exception $e) {
        return false;
    }
}

$schemaApplied = false;
if (!tablesExist($pdo)) {
    $sqlFile = __DIR__ . '/sql/schema.sql';
    if (!file_exists($sqlFile)) {
        die('Fichier sql/schema.sql introuvable.');
    }
    $sql = file_get_contents($sqlFile);
    // Retire les lignes de commentaire (-- ...) avant de découper sur les points-virgules,
    // pour ne pas ignorer par erreur des instructions qui commencent par une ligne de commentaire.
    $sqlSansCommentaires = preg_replace('/^\s*--.*$/m', '', $sql);
    $statements = array_filter(array_map('trim', explode(';', $sqlSansCommentaires)));
    try {
        foreach ($statements as $statement) {
            $statement = trim($statement);
            if ($statement === '') {
                continue;
            }
            $pdo->exec($statement);
        }
        $schemaApplied = true;
    } catch (Exception $e) {
        die('Erreur lors de la création des tables : ' . htmlspecialchars($e->getMessage()));
    }
}

// Si un utilisateur existe déjà, on bloque l'accès à ce script.
$userCount = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$done = false;
$error = '';

if ($userCount === 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = trim($_POST['nom_complet'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if ($nom === '' || $username === '' || $password === '') {
        $error = 'Merci de remplir tous les champs obligatoires.';
    } elseif ($password !== $password2) {
        $error = 'Les deux mots de passe ne correspondent pas.';
    } elseif (strlen($password) < 8) {
        $error = 'Le mot de passe doit contenir au moins 8 caractères.';
    } else {
        $stmt = $pdo->prepare('INSERT INTO users (username, password_hash, nom_complet, email) VALUES (?, ?, ?, ?)');
        $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $nom, $email]);
        $done = true;
        $userCount = 1;
    }
}
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Installation — CRM Fibromed</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="login-wrap">
  <div class="login-box" style="max-width:440px;">
    <div class="brand">FIBRO<span>MED</span></div>
    <div class="tagline">Installation initiale du CRM</div>

    <?php if ($schemaApplied): ?>
      <div class="flash success">Tables de la base de données créées avec succès.</div>
    <?php endif; ?>

    <?php if ($userCount > 0 && !$done): ?>
      <div class="flash info">Un compte existe déjà. L'installation a déjà été effectuée.</div>
      <p style="text-align:center;"><a href="login.php" class="btn">Aller à la connexion</a></p>
    <?php elseif ($done): ?>
      <div class="flash success">Compte administrateur créé avec succès !</div>
      <p style="font-size:13.5px;color:#9B2C2C;">Par sécurité, supprimez maintenant le fichier <code>install.php</code> de votre hébergement.</p>
      <p style="text-align:center;"><a href="login.php" class="btn">Se connecter</a></p>
    <?php else: ?>
      <?php if ($error): ?><div class="flash error"><?= e($error) ?></div><?php endif; ?>
      <form method="post" action="install.php">
        <div class="form-row">
          <label>Nom complet</label>
          <input type="text" name="nom_complet" required value="<?= e($_POST['nom_complet'] ?? 'Aymen Habibellah') ?>">
        </div>
        <div class="form-row">
          <label>Identifiant de connexion</label>
          <input type="text" name="username" required value="<?= e($_POST['username'] ?? 'aymen') ?>">
        </div>
        <div class="form-row">
          <label>Email (optionnel)</label>
          <input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>">
        </div>
        <div class="form-row">
          <label>Mot de passe (8 caractères minimum)</label>
          <input type="password" name="password" required minlength="8">
        </div>
        <div class="form-row">
          <label>Confirmer le mot de passe</label>
          <input type="password" name="password2" required minlength="8">
        </div>
        <button type="submit" class="btn">Créer le compte administrateur</button>
      </form>
    <?php endif; ?>
  </div>
</div>
</body>
</html>

<?php
$pageTitle = 'Établissement';
$activeNav = 'etablissements';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$etab = ['nom' => '', 'secteur' => '', 'ville' => '', 'pays' => 'Maroc', 'adresse' => '', 'telephone' => '', 'email' => '', 'notes' => ''];

if ($id) {
    $stmt = $pdo->prepare('SELECT * FROM etablissements WHERE id = ?');
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) {
        flash('error', 'Établissement introuvable.');
        redirect('etablissements.php');
    }
    $etab = $found;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    foreach (['nom','secteur','ville','pays','adresse','telephone','email','notes'] as $f) {
        $etab[$f] = trim($_POST[$f] ?? '');
    }
    if ($etab['nom'] === '') {
        $errors[] = "Le nom de l'établissement est obligatoire.";
    }
    if (empty($errors)) {
        if ($id) {
            $stmt = $pdo->prepare('UPDATE etablissements SET nom=?, secteur=?, ville=?, pays=?, adresse=?, telephone=?, email=?, notes=? WHERE id=?');
            $stmt->execute([$etab['nom'], $etab['secteur'], $etab['ville'], $etab['pays'], $etab['adresse'], $etab['telephone'], $etab['email'], $etab['notes'], $id]);
            flash('success', 'Établissement mis à jour.');
            redirect('etablissement_view.php?id=' . $id);
        } else {
            $stmt = $pdo->prepare('INSERT INTO etablissements (nom, secteur, ville, pays, adresse, telephone, email, notes) VALUES (?,?,?,?,?,?,?,?)');
            $stmt->execute([$etab['nom'], $etab['secteur'], $etab['ville'], $etab['pays'], $etab['adresse'], $etab['telephone'], $etab['email'], $etab['notes']]);
            $newId = $pdo->lastInsertId();
            flash('success', 'Établissement créé.');
            redirect('etablissement_view.php?id=' . $newId);
        }
    }
}
?>

<div class="page-header">
  <h1><?= $id ? 'Modifier l\'établissement' : 'Nouvel établissement' ?></h1>
</div>

<?php foreach ($errors as $err): ?><div class="flash error"><?= e($err) ?></div><?php endforeach; ?>

<div class="card">
  <form method="post" action="etablissement_form.php<?= $id ? '?id=' . $id : '' ?>">
    <?= csrfField() ?>
    <div class="form-grid">
      <div class="form-row">
        <label>Nom *</label>
        <input type="text" name="nom" required value="<?= e($etab['nom']) ?>">
      </div>
      <div class="form-row">
        <label>Secteur</label>
        <input type="text" name="secteur" placeholder="Hôpital, clinique..." value="<?= e($etab['secteur']) ?>">
      </div>
      <div class="form-row">
        <label>Ville</label>
        <input type="text" name="ville" value="<?= e($etab['ville']) ?>">
      </div>
      <div class="form-row">
        <label>Pays</label>
        <input type="text" name="pays" value="<?= e($etab['pays']) ?>">
      </div>
      <div class="form-row">
        <label>Téléphone</label>
        <input type="tel" name="telephone" value="<?= e($etab['telephone']) ?>">
      </div>
      <div class="form-row">
        <label>Email</label>
        <input type="email" name="email" value="<?= e($etab['email']) ?>">
      </div>
    </div>
    <div class="form-row">
      <label>Adresse</label>
      <input type="text" name="adresse" value="<?= e($etab['adresse']) ?>">
    </div>
    <div class="form-row">
      <label>Notes</label>
      <textarea name="notes"><?= e($etab['notes']) ?></textarea>
    </div>
    <div class="form-actions">
      <button type="submit" class="btn">Enregistrer</button>
      <a href="<?= $id ? 'etablissement_view.php?id=' . $id : 'etablissements.php' ?>" class="btn btn-secondary">Annuler</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

<?php
$pageTitle = 'Devis / Facture';
$activeNav = 'documents';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

$doc = [
    'type' => $_GET['type'] ?? 'devis',
    'etablissement_id' => '', 'contact_id' => '',
    'date_emission' => todayIso(), 'date_echeance' => '',
    'statut' => 'brouillon', 'taux_tva' => getSetting('taux_tva', '20'), 'notes' => ''
];
$lignes = [];

if ($id) {
    $stmt = $pdo->prepare("SELECT * FROM documents WHERE id = ? AND type IN ('devis','facture')");
    $stmt->execute([$id]);
    $found = $stmt->fetch();
    if (!$found) {
        flash('error', 'Document introuvable.');
        redirect('documents.php');
    }
    $doc = $found;
    $stmt = $pdo->prepare('SELECT * FROM document_lignes WHERE document_id = ? ORDER BY ordre ASC, id ASC');
    $stmt->execute([$id]);
    $lignes = $stmt->fetchAll();
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfCheck();
    $doc['type'] = $_POST['type'] ?? 'devis';
    $doc['etablissement_id'] = $_POST['etablissement_id'] ?: null;
    $doc['contact_id'] = $_POST['contact_id'] ?: null;
    $doc['date_emission'] = $_POST['date_emission'] ?: todayIso();
    $doc['date_echeance'] = $_POST['date_echeance'] ?: null;
    $doc['statut'] = $_POST['statut'] ?? 'brouillon';
    $doc['taux_tva'] = (float)($_POST['taux_tva'] ?? 20);
    $doc['notes'] = trim($_POST['notes'] ?? '');

    $lignesPost = $_POST['lignes'] ?? [];
    $lignes = [];
    $totalHt = 0;
    $ordre = 0;
    foreach ($lignesPost as $l) {
        $designation = trim($l['designation'] ?? '');
        $quantite = (float)($l['quantite'] ?? 0);
        $prixUnitaire = (float)($l['prix_unitaire'] ?? 0);
        if ($designation === '' && $quantite == 0 && $prixUnitaire == 0) {
            continue;
        }
        $lignes[] = ['designation' => $designation, 'quantite' => $quantite, 'prix_unitaire' => $prixUnitaire, 'ordre' => $ordre++];
        $totalHt += $quantite * $prixUnitaire;
    }

    if (empty($doc['etablissement_id'])) {
        $errors[] = "Merci de sélectionner un établissement.";
    }
    if (empty($lignes)) {
        $errors[] = "Ajoutez au moins une ligne au document.";
    }

    if (empty($errors)) {
        $totalTva = $totalHt * ($doc['taux_tva'] / 100);
        $totalTtc = $totalHt + $totalTva;

        if ($id) {
            $stmt = $pdo->prepare('UPDATE documents SET type=?, etablissement_id=?, contact_id=?, date_emission=?, date_echeance=?, statut=?, taux_tva=?, total_ht=?, total_tva=?, total_ttc=?, notes=? WHERE id=?');
            $stmt->execute([$doc['type'], $doc['etablissement_id'], $doc['contact_id'], $doc['date_emission'], $doc['date_echeance'], $doc['statut'], $doc['taux_tva'], $totalHt, $totalTva, $totalTtc, $doc['notes'], $id]);

            $pdo->prepare('DELETE FROM document_lignes WHERE document_id = ?')->execute([$id]);
            $stmtLigne = $pdo->prepare('INSERT INTO document_lignes (document_id, designation, quantite, prix_unitaire, ordre) VALUES (?,?,?,?,?)');
            foreach ($lignes as $l) {
                $stmtLigne->execute([$id, $l['designation'], $l['quantite'], $l['prix_unitaire'], $l['ordre']]);
            }
            flash('success', 'Document mis à jour.');
            redirect('document_view.php?id=' . $id);
        } else {
            $numero = generateDocumentNumber($doc['type']);
            $stmt = $pdo->prepare('INSERT INTO documents (type, numero, etablissement_id, contact_id, date_emission, date_echeance, statut, taux_tva, total_ht, total_tva, total_ttc, notes) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
            $stmt->execute([$doc['type'], $numero, $doc['etablissement_id'], $doc['contact_id'], $doc['date_emission'], $doc['date_echeance'], $doc['statut'], $doc['taux_tva'], $totalHt, $totalTva, $totalTtc, $doc['notes']]);
            $newId = $pdo->lastInsertId();
            $stmtLigne = $pdo->prepare('INSERT INTO document_lignes (document_id, designation, quantite, prix_unitaire, ordre) VALUES (?,?,?,?,?)');
            foreach ($lignes as $l) {
                $stmtLigne->execute([$newId, $l['designation'], $l['quantite'], $l['prix_unitaire'], $l['ordre']]);
            }
            flash('success', "Document $numero créé.");
            redirect('document_view.php?id=' . $newId);
        }
    }
}

$etablissements = getEtablissementsList();
$stmt = $pdo->query('SELECT id, prenom, nom, etablissement_id FROM contacts ORDER BY nom ASC');
$allContacts = $stmt->fetchAll();
$statutsListe = ['brouillon' => 'Brouillon', 'envoyé' => 'Envoyé', 'accepté' => 'Accepté', 'payé' => 'Payé', 'en_retard' => 'En retard', 'annulé' => 'Annulé'];

if (empty($lignes)) {
    $lignes = [['designation' => '', 'quantite' => 1, 'prix_unitaire' => 0]];
}
?>

<div class="page-header">
  <h1><?= $id ? 'Modifier le document' : 'Nouveau devis / facture' ?></h1>
</div>

<?php foreach ($errors as $err): ?><div class="flash error"><?= e($err) ?></div><?php endforeach; ?>

<div class="card">
  <form method="post" action="document_form.php<?= $id ? '?id=' . $id : '' ?>">
    <?= csrfField() ?>
    <div class="form-grid">
      <div class="form-row">
        <label>Type de document</label>
        <select name="type">
          <option value="devis" <?= $doc['type'] === 'devis' ? 'selected' : '' ?>>Devis</option>
          <option value="facture" <?= $doc['type'] === 'facture' ? 'selected' : '' ?>>Facture</option>
        </select>
      </div>
      <div class="form-row">
        <label>Statut</label>
        <select name="statut">
          <?php foreach ($statutsListe as $key => $label): ?>
            <option value="<?= e($key) ?>" <?= $doc['statut'] === $key ? 'selected' : '' ?>><?= e($label) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Établissement *</label>
        <select name="etablissement_id" required>
          <option value="">— Choisir —</option>
          <?php foreach ($etablissements as $e): ?>
            <option value="<?= (int)$e['id'] ?>" <?= (string)$doc['etablissement_id'] === (string)$e['id'] ? 'selected' : '' ?>><?= e($e['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Contact (optionnel)</label>
        <select name="contact_id">
          <option value="">— Aucun —</option>
          <?php foreach ($allContacts as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= (string)$doc['contact_id'] === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['prenom'] . ' ' . $c['nom']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-row">
        <label>Date d'émission</label>
        <input type="date" name="date_emission" value="<?= e($doc['date_emission']) ?>">
      </div>
      <div class="form-row">
        <label>Date d'échéance</label>
        <input type="date" name="date_echeance" value="<?= e($doc['date_echeance']) ?>">
      </div>
      <div class="form-row">
        <label>Taux de TVA (%)</label>
        <input type="number" step="0.01" id="taux_tva" name="taux_tva" value="<?= e((string)$doc['taux_tva']) ?>">
      </div>
    </div>

    <h2 style="margin-top:10px;">Lignes du document</h2>
    <div class="table-wrap">
      <table id="lignes-table">
        <thead><tr><th>Désignation</th><th>Qté</th><th>Prix unitaire</th><th>Total</th><th></th></tr></thead>
        <tbody id="lignes-body">
          <?php foreach ($lignes as $i => $l): ?>
            <tr>
              <td><input type="text" name="lignes[<?= $i ?>][designation]" value="<?= e($l['designation']) ?>" placeholder="Désignation"></td>
              <td style="width:90px"><input type="number" step="0.01" min="0" name="lignes[<?= $i ?>][quantite]" value="<?= e((string)$l['quantite']) ?>" class="qte"></td>
              <td style="width:130px"><input type="number" step="0.01" min="0" name="lignes[<?= $i ?>][prix_unitaire]" value="<?= e((string)$l['prix_unitaire']) ?>" class="pu"></td>
              <td style="width:130px" class="ligne-total"><?= number_format($l['quantite'] * $l['prix_unitaire'], 2, ',', ' ') ?></td>
              <td style="width:40px"><button type="button" class="btn btn-sm btn-danger remove-ligne">✕</button></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <button type="button" id="add-ligne-btn" class="btn btn-sm btn-secondary" style="margin-top:10px;">+ Ajouter une ligne</button>

    <div style="max-width:320px;margin-left:auto;margin-top:18px;">
      <table>
        <tr><td>Total HT</td><td style="text-align:right"><span id="total-ht">0,00</span> <?= e(getSetting('devise', 'MAD')) ?></td></tr>
        <tr><td>TVA</td><td style="text-align:right"><span id="total-tva">0,00</span> <?= e(getSetting('devise', 'MAD')) ?></td></tr>
        <tr><td><strong>Total TTC</strong></td><td style="text-align:right"><strong><span id="total-ttc">0,00</span> <?= e(getSetting('devise', 'MAD')) ?></strong></td></tr>
      </table>
    </div>

    <div class="form-row" style="margin-top:16px;">
      <label>Notes (visibles sur le document)</label>
      <textarea name="notes"><?= e($doc['notes']) ?></textarea>
    </div>

    <div class="form-actions">
      <button type="submit" class="btn">Enregistrer</button>
      <a href="<?= $id ? 'document_view.php?id=' . $id : 'documents.php' ?>" class="btn btn-secondary">Annuler</a>
    </div>
  </form>
</div>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>

<?php
// Attendu avant inclusion : $pageTitle (string), $activeNav (string, optionnel)
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
requireLogin();
$user = currentUser();
$activeNav = $activeNav ?? '';
$navItems = [
    'dashboard' => ['label' => 'Tableau de bord', 'href' => 'index.php'],
    'contacts' => ['label' => 'Contacts', 'href' => 'contacts.php'],
    'etablissements' => ['label' => 'Établissements', 'href' => 'etablissements.php'],
    'reparations' => ['label' => 'Réparations', 'href' => 'reparations.php'],
    'documents' => ['label' => 'Devis & Factures', 'href' => 'documents.php'],
    'statuts' => ['label' => 'Statuts pipeline', 'href' => 'statuts.php'],
    'parametres' => ['label' => 'Paramètres', 'href' => 'parametres.php'],
];
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle ?? 'CRM Fibromed') ?> — CRM Fibromed</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="topbar-mobile">
  <div class="brand">FIBRO<span>MED</span></div>
  <button id="mobile-menu-toggle" aria-label="Menu">☰</button>
</div>
<div class="sidebar-overlay" id="sidebar-overlay"></div>
<div class="app-shell">
  <aside class="sidebar" id="sidebar">
    <div class="brand">FIBRO<span>MED</span></div>
    <nav>
      <?php foreach ($navItems as $key => $item): ?>
        <a href="<?= e($item['href']) ?>" class="<?= $activeNav === $key ? 'active' : '' ?>"><?= e($item['label']) ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="user-box">
      Connecté : <strong><?= e($user['nom_complet'] ?? '') ?></strong>
      <form method="post" action="logout.php">
        <button type="submit">Se déconnecter</button>
      </form>
    </div>
  </aside>
  <main class="main-content">
    <?php foreach (getFlashes() as $f): ?>
      <div class="flash <?= e($f['type']) ?>"><?= e($f['message']) ?></div>
    <?php endforeach; ?>

<?php
require_once __DIR__ . '/../lib/fpdf.php';
require_once __DIR__ . '/functions.php';

/**
 * Convertit une chaîne UTF-8 vers l'encodage attendu par FPDF (ISO-8859-1),
 * en conservant les caractères accentués français.
 */
function pdfText(?string $text): string
{
    $text = $text ?? '';
    if (function_exists('iconv')) {
        $converted = @iconv('UTF-8', 'ISO-8859-1//TRANSLIT', $text);
        if ($converted !== false) {
            return $converted;
        }
    }
    return mb_convert_encoding($text, 'ISO-8859-1', 'UTF-8');
}

class FibromedPDF extends FPDF
{
    public string $docTitle = '';

    function Header(): void
    {
        $logoPath = __DIR__ . '/../assets/img/logo-fibromed.jpg';
        if (file_exists($logoPath)) {
            // Logo Fibromed (fond blanc), largeur 58mm, hauteur calculée automatiquement.
            $this->Image($logoPath, 15, 10, 58);
        } else {
            $this->SetFont('Helvetica', 'B', 18);
            $this->SetTextColor(0x1A, 0x20, 0x50);
            $this->SetXY(15, 14);
            $this->Cell(0, 10, pdfText('FIBROMED'), 0, 0, 'L');
        }

        $this->SetFont('Helvetica', '', 8.5);
        $this->SetTextColor(90, 90, 90);
        $this->SetXY(115, 13);
        $this->Cell(80, 5, pdfText("Maintenance & réparation d'endoscopes médicaux"), 0, 0, 'R');
        $this->SetXY(115, 19);
        $this->Cell(80, 5, pdfText(getSetting('adresse', '')), 0, 0, 'R');

        $this->SetDrawColor(0x1A, 0x20, 0x50);
        $this->SetLineWidth(0.6);
        $this->Line(15, 36, 195, 36);
        $this->SetLineWidth(0.2);
        $this->SetDrawColor(0, 0, 0);
        $this->SetTextColor(0, 0, 0);
        $this->SetY(42);
    }

    function Footer(): void
    {
        $this->SetY(-26);
        $this->SetDrawColor(220, 220, 220);
        $this->Line(15, $this->GetY(), 195, $this->GetY());
        $this->SetY(-22);
        $this->SetFont('Helvetica', '', 7.5);
        $this->SetTextColor(110, 110, 110);
        $raison = getSetting('raison_sociale', 'FIBROMED SARL');
        $rc = getSetting('rc', '');
        $tribunal = getSetting('tribunal_rc', '');
        $if = getSetting('if_fiscal', '');
        $ice = getSetting('ice', '');
        $adresse = getSetting('adresse', '');
        $gerantTel = getSetting('gerant_telephone', '');
        $gerantEmail = getSetting('gerant_email', '');

        $ligne1 = trim("$raison - RC $rc" . ($tribunal ? " ($tribunal)" : '') . " - IF $if - ICE $ice");
        $ligne2 = $adresse;
        $contactParts = array_filter([$gerantTel !== '' ? "Tél. $gerantTel" : '', $gerantEmail]);
        $ligne3 = implode('  —  ', $contactParts);

        $this->Cell(0, 4, pdfText($ligne1), 0, 1, 'C');
        $this->Cell(0, 4, pdfText($ligne2), 0, 1, 'C');
        if ($ligne3 !== '') {
            $this->Cell(0, 4, pdfText($ligne3), 0, 0, 'C');
        }
    }
}

/**
 * Tronque un texte (avec "...") pour qu'il tienne dans une largeur de cellule donnée,
 * afin d'éviter tout chevauchement avec la colonne suivante (Cell() ne fait pas de retour à la ligne).
 * Doit être appelé après avoir défini la police (SetFont) qui sera utilisée pour l'affichage.
 */
function pdfFitCellText(FPDF $pdf, string $text, float $maxWidthMm): string
{
    $converted = pdfText($text);
    $usable = max(0, $maxWidthMm - 2); // marge intérieure approximative des Cell (1mm de chaque côté)
    if ($pdf->GetStringWidth($converted) <= $usable) {
        return $converted;
    }
    $ellipsis = '...';
    while ($converted !== '' && $pdf->GetStringWidth($converted . $ellipsis) > $usable) {
        $converted = substr($converted, 0, -1);
    }
    return $converted . $ellipsis;
}

/**
 * Bloc "Destinataire" commun aux devis/factures/bons de livraison.
 */
function pdfBlocDestinataire(FibromedPDF $pdf, array $doc): void
{
    $pdf->SetFont('Helvetica', 'B', 10.5);
    $pdf->Cell(0, 6, pdfText('Destinataire'), 0, 1);
    $pdf->SetFont('Helvetica', '', 10.5);
    if (!empty($doc['etablissement_nom'])) {
        $pdf->Cell(0, 5.5, pdfText($doc['etablissement_nom']), 0, 1);
    }
    if (!empty($doc['contact_prenom']) || !empty($doc['contact_nom'])) {
        $pdf->Cell(0, 5.5, pdfText('A l\'attention de : ' . trim($doc['contact_prenom'] . ' ' . $doc['contact_nom'])), 0, 1);
    }
    if (!empty($doc['etablissement_adresse'])) {
        $pdf->Cell(0, 5.5, pdfText($doc['etablissement_adresse']), 0, 1);
    }
    $villePays = trim(($doc['etablissement_ville'] ?? '') . ' ' . ($doc['etablissement_pays'] ?? ''));
    if ($villePays !== '') {
        $pdf->Cell(0, 5.5, pdfText($villePays), 0, 1);
    }
    $pdf->Ln(6);
}

/**
 * Génère le PDF d'un devis ou d'une facture.
 * $mode : 'I' (affichage navigateur), 'D' (téléchargement), 'S' (retourne la chaîne binaire)
 */
function generateDocumentPdf(int $documentId, string $mode = 'I')
{
    $pdo = getPDO();

    $stmt = $pdo->prepare('
        SELECT d.*, e.nom AS etablissement_nom, e.adresse AS etablissement_adresse,
               e.ville AS etablissement_ville, e.pays AS etablissement_pays,
               c.prenom AS contact_prenom, c.nom AS contact_nom
        FROM documents d
        LEFT JOIN etablissements e ON e.id = d.etablissement_id
        LEFT JOIN contacts c ON c.id = d.contact_id
        WHERE d.id = ? AND d.type IN (\'devis\',\'facture\')
    ');
    $stmt->execute([$documentId]);
    $doc = $stmt->fetch();
    if (!$doc) {
        throw new RuntimeException('Document introuvable.');
    }

    $stmt = $pdo->prepare('SELECT * FROM document_lignes WHERE document_id = ? ORDER BY ordre ASC, id ASC');
    $stmt->execute([$documentId]);
    $lignes = $stmt->fetchAll();

    $pdf = new FibromedPDF('P', 'mm', 'A4');
    $pdf->SetTitle(pdfText($doc['numero']));
    $pdf->SetMargins(15, 15, 15);
    $pdf->AddPage();

    // Titre du document + numéro / dates
    $typeLabel = $doc['type'] === 'devis' ? 'DEVIS' : 'FACTURE';
    $pdf->SetFont('Helvetica', 'B', 15);
    $pdf->SetTextColor(0x1A, 0x20, 0x50);
    $pdf->Cell(0, 9, pdfText("$typeLabel N° " . $doc['numero']), 0, 1, 'R');
    $pdf->SetFont('Helvetica', '', 10);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(0, 6, pdfText('Date d\'émission : ' . formatDateFr($doc['date_emission'])), 0, 1, 'R');
    if ($doc['date_echeance']) {
        $pdf->Cell(0, 6, pdfText('Date d\'échéance : ' . formatDateFr($doc['date_echeance'])), 0, 1, 'R');
    }

    // Mention "Établi par ..., Gérant" — sur les devis.
    if ($doc['type'] === 'devis') {
        $gerantNom = getSetting('gerant_nom', 'Aymen Habibellah');
        $pdf->SetFont('Helvetica', 'I', 9);
        $pdf->SetTextColor(90, 90, 90);
        $pdf->Cell(0, 6, pdfText('Devis établi par ' . $gerantNom . ', Gérant'), 0, 1, 'R');
        $pdf->SetTextColor(0, 0, 0);
    }
    $pdf->Ln(4);

    // Bloc client
    pdfBlocDestinataire($pdf, $doc);

    // Tableau des lignes
    $pdf->SetFillColor(0x1A, 0x20, 0x50);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetFont('Helvetica', 'B', 9.5);
    $colDesignation = 90;
    $colQte = 20;
    $colPu = 35;
    $colTotal = 35;
    $pdf->Cell($colDesignation, 8, pdfText('Désignation'), 0, 0, 'L', true);
    $pdf->Cell($colQte, 8, pdfText('Qté'), 0, 0, 'C', true);
    $pdf->Cell($colPu, 8, pdfText('Prix unit.'), 0, 0, 'R', true);
    $pdf->Cell($colTotal, 8, pdfText('Total'), 0, 1, 'R', true);

    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont('Helvetica', '', 9.5);
    $fill = false;
    foreach ($lignes as $ligne) {
        $totalLigne = $ligne['quantite'] * $ligne['prix_unitaire'];
        $pdf->SetFillColor(245, 246, 250);
        $pdf->Cell($colDesignation, 7.5, pdfFitCellText($pdf, $ligne['designation'], $colDesignation), 0, 0, 'L', $fill);
        $pdf->Cell($colQte, 7.5, pdfText(rtrim(rtrim(number_format($ligne['quantite'], 2, ',', ' '), '0'), ',')), 0, 0, 'C', $fill);
        $pdf->Cell($colPu, 7.5, pdfText(number_format($ligne['prix_unitaire'], 2, ',', ' ')), 0, 0, 'R', $fill);
        $pdf->Cell($colTotal, 7.5, pdfText(number_format($totalLigne, 2, ',', ' ')), 0, 1, 'R', $fill);
        $fill = !$fill;
    }

    $pdf->Ln(4);

    // Totaux
    $devise = getSetting('devise', 'MAD');
    $labelWidth = $colDesignation + $colQte;
    $pdf->SetFont('Helvetica', '', 10);
    $pdf->Cell($labelWidth, 7, '', 0, 0);
    $pdf->Cell($colPu, 7, pdfText('Total HT'), 0, 0, 'R');
    $pdf->Cell($colTotal, 7, pdfText(number_format($doc['total_ht'], 2, ',', ' ') . ' ' . $devise), 0, 1, 'R');

    $pdf->Cell($labelWidth, 7, '', 0, 0);
    $pdf->Cell($colPu, 7, pdfText('TVA (' . rtrim(rtrim(number_format($doc['taux_tva'], 2), '0'), '.') . '%)'), 0, 0, 'R');
    $pdf->Cell($colTotal, 7, pdfText(number_format($doc['total_tva'], 2, ',', ' ') . ' ' . $devise), 0, 1, 'R');

    $pdf->SetFont('Helvetica', 'B', 11);
    $pdf->SetDrawColor(0x1A, 0x20, 0x50);
    $pdf->Cell($labelWidth, 9, '', 0, 0);
    $pdf->Cell($colPu, 9, pdfText('Total TTC'), 'T', 0, 'R');
    $pdf->Cell($colTotal, 9, pdfText(number_format($doc['total_ttc'], 2, ',', ' ') . ' ' . $devise), 'T', 1, 'R');

    if (!empty($doc['notes'])) {
        $pdf->Ln(8);
        $pdf->SetFont('Helvetica', 'B', 9.5);
        $pdf->Cell(0, 6, pdfText('Notes'), 0, 1);
        $pdf->SetFont('Helvetica', '', 9.5);
        $pdf->MultiCell(0, 5.5, pdfText($doc['notes']));
    }

    // Clause juridique de réserve de propriété — sur tous les devis.
    if ($doc['type'] === 'devis') {
        $clause = getSetting('clause_juridique', '');
        if ($clause !== '') {
            $pdf->Ln(7);
            $pdf->SetFont('Helvetica', 'I', 8);
            $pdf->SetTextColor(90, 90, 90);
            $pdf->SetFillColor(245, 246, 250);
            $pdf->MultiCell(0, 4.6, pdfText($clause), 0, 'L', true);
            $pdf->SetTextColor(0, 0, 0);
        }
    }

    $filename = pdfText($doc['numero']) . '.pdf';

    if ($mode === 'S') {
        return $pdf->Output('S');
    }
    $pdf->Output($mode, $filename);
    return null;
}

/**
 * Génère le PDF d'un bon de livraison (preuve de livraison du matériel, sans prix).
 * $mode : 'I' (affichage navigateur), 'D' (téléchargement), 'S' (retourne la chaîne binaire)
 */
function generateBonLivraisonPdf(int $documentId, string $mode = 'I')
{
    $pdo = getPDO();

    $stmt = $pdo->prepare('
        SELECT d.*, e.nom AS etablissement_nom, e.adresse AS etablissement_adresse,
               e.ville AS etablissement_ville, e.pays AS etablissement_pays,
               c.prenom AS contact_prenom, c.nom AS contact_nom,
               f.numero AS facture_numero
        FROM documents d
        LEFT JOIN etablissements e ON e.id = d.etablissement_id
        LEFT JOIN contacts c ON c.id = d.contact_id
        LEFT JOIN documents f ON f.id = d.facture_source_id
        WHERE d.id = ? AND d.type = \'bon_livraison\'
    ');
    $stmt->execute([$documentId]);
    $doc = $stmt->fetch();
    if (!$doc) {
        throw new RuntimeException('Bon de livraison introuvable.');
    }

    $stmt = $pdo->prepare('SELECT * FROM bon_livraison_lignes WHERE document_id = ? ORDER BY ordre ASC, id ASC');
    $stmt->execute([$documentId]);
    $lignes = $stmt->fetchAll();

    $pdf = new FibromedPDF('P', 'mm', 'A4');
    $pdf->SetTitle(pdfText($doc['numero']));
    $pdf->SetMargins(15, 15, 15);
    $pdf->AddPage();

    $pdf->SetFont('Helvetica', 'B', 15);
    $pdf->SetTextColor(0x1A, 0x20, 0x50);
    $pdf->Cell(0, 9, pdfText('BON DE LIVRAISON N° ' . $doc['numero']), 0, 1, 'R');
    $pdf->SetFont('Helvetica', '', 10);
    $pdf->SetTextColor(0, 0, 0);
    $pdf->Cell(0, 6, pdfText('Date de livraison : ' . formatDateFr($doc['date_emission'])), 0, 1, 'R');
    if (!empty($doc['facture_numero'])) {
        $pdf->Cell(0, 6, pdfText('Relatif à la facture N° ' . $doc['facture_numero']), 0, 1, 'R');
    }
    $pdf->Ln(4);

    pdfBlocDestinataire($pdf, $doc);

    // Tableau du matériel livré
    $pdf->SetFillColor(0x1A, 0x20, 0x50);
    $pdf->SetTextColor(255, 255, 255);
    $pdf->SetFont('Helvetica', 'B', 9);
    $colDesignation = 58;
    $colMarque = 30;
    $colModele = 32;
    $colSerie = 35;
    $colQte = 25;
    $pdf->Cell($colDesignation, 8, pdfText('Désignation'), 0, 0, 'L', true);
    $pdf->Cell($colMarque, 8, pdfText('Marque'), 0, 0, 'L', true);
    $pdf->Cell($colModele, 8, pdfText('Modèle'), 0, 0, 'L', true);
    $pdf->Cell($colSerie, 8, pdfText('N° de série'), 0, 0, 'L', true);
    $pdf->Cell($colQte, 8, pdfText('Qté'), 0, 1, 'C', true);

    $pdf->SetTextColor(0, 0, 0);
    $pdf->SetFont('Helvetica', '', 9);
    $fill = false;
    foreach ($lignes as $ligne) {
        $pdf->SetFillColor(245, 246, 250);
        $pdf->Cell($colDesignation, 7.5, pdfFitCellText($pdf, $ligne['designation'], $colDesignation), 0, 0, 'L', $fill);
        $pdf->Cell($colMarque, 7.5, pdfFitCellText($pdf, $ligne['marque'] ?? '', $colMarque), 0, 0, 'L', $fill);
        $pdf->Cell($colModele, 7.5, pdfFitCellText($pdf, $ligne['modele'] ?? '', $colModele), 0, 0, 'L', $fill);
        $pdf->Cell($colSerie, 7.5, pdfFitCellText($pdf, $ligne['numero_serie'] ?? '', $colSerie), 0, 0, 'L', $fill);
        $pdf->Cell($colQte, 7.5, pdfText(rtrim(rtrim(number_format($ligne['quantite'], 2, ',', ' '), '0'), ',')), 0, 1, 'C', $fill);
        $fill = !$fill;
    }

    if (!empty($doc['notes'])) {
        $pdf->Ln(8);
        $pdf->SetFont('Helvetica', 'B', 9.5);
        $pdf->Cell(0, 6, pdfText('Notes'), 0, 1);
        $pdf->SetFont('Helvetica', '', 9.5);
        $pdf->MultiCell(0, 5.5, pdfText($doc['notes']));
    }

    // Bloc attestation + signatures
    $pdf->Ln(10);
    $pdf->SetFont('Helvetica', '', 9.5);
    $pdf->MultiCell(0, 5.5, pdfText("Je soussigné(e), reconnais avoir reçu, en bon état et en quantité conforme, le matériel décrit ci-dessus."));
    $pdf->Ln(10);

    $y = $pdf->GetY();
    $pdf->SetFont('Helvetica', 'B', 9.5);
    $pdf->SetXY(15, $y);
    $pdf->Cell(85, 6, pdfText('Cachet et signature du client'), 0, 0, 'L');
    $pdf->SetXY(110, $y);
    $pdf->Cell(85, 6, pdfText('Pour FIBROMED SARL'), 0, 1, 'L');
    $pdf->SetDrawColor(200, 200, 200);
    $pdf->Rect(15, $y + 8, 85, 28);
    $pdf->Rect(110, $y + 8, 85, 28);

    $filename = pdfText($doc['numero']) . '.pdf';

    if ($mode === 'S') {
        return $pdf->Output('S');
    }
    $pdf->Output($mode, $filename);
    return null;
}

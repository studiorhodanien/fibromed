<?php
require_once __DIR__ . '/db.php';

function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function getFlashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $flashes;
}

function formatMoney($amount): string
{
    $devise = getSetting('devise', 'MAD');
    return number_format((float)$amount, 2, ',', ' ') . ' ' . $devise;
}

function formatDateFr(?string $date): string
{
    if (empty($date) || $date === '0000-00-00') {
        return '—';
    }
    $ts = strtotime($date);
    if ($ts === false) {
        return '—';
    }
    return date('d/m/Y', $ts);
}

function todayIso(): string
{
    return date('Y-m-d');
}

// --- Paramètres de l'entreprise (table "parametres") ---
function getAllSettings(): array
{
    static $settings = null;
    if ($settings === null) {
        $settings = [];
        $stmt = getPDO()->query('SELECT cle, valeur FROM parametres');
        foreach ($stmt->fetchAll() as $row) {
            $settings[$row['cle']] = $row['valeur'];
        }
    }
    return $settings;
}

function getSetting(string $key, string $default = ''): string
{
    $settings = getAllSettings();
    return $settings[$key] ?? $default;
}

function setSetting(string $key, string $value): void
{
    $stmt = getPDO()->prepare('INSERT INTO parametres (cle, valeur) VALUES (?, ?) ON DUPLICATE KEY UPDATE valeur = VALUES(valeur)');
    $stmt->execute([$key, $value]);
}

// --- Statuts du pipeline ---
function getStatuts(bool $actifsOnly = true): array
{
    $sql = 'SELECT * FROM statuts';
    if ($actifsOnly) {
        $sql .= ' WHERE actif = 1';
    }
    $sql .= ' ORDER BY ordre ASC, id ASC';
    return getPDO()->query($sql)->fetchAll();
}

function getStatutNom(?int $id): string
{
    if (!$id) {
        return '—';
    }
    static $cache = [];
    if (!array_key_exists($id, $cache)) {
        $stmt = getPDO()->prepare('SELECT nom FROM statuts WHERE id = ?');
        $stmt->execute([$id]);
        $row = $stmt->fetch();
        $cache[$id] = $row ? $row['nom'] : '—';
    }
    return $cache[$id];
}

// --- Établissements (listes déroulantes) ---
function getEtablissementsList(): array
{
    return getPDO()->query('SELECT id, nom FROM etablissements ORDER BY nom ASC')->fetchAll();
}

function getContactsByEtablissement(int $etablissementId): array
{
    $stmt = getPDO()->prepare('SELECT id, prenom, nom FROM contacts WHERE etablissement_id = ? ORDER BY nom ASC');
    $stmt->execute([$etablissementId]);
    return $stmt->fetchAll();
}

// --- Numérotation séquentielle des devis / factures / bons de livraison ---
function generateDocumentNumber(string $type): string
{
    $pdo = getPDO();
    $year = date('Y');
    if ($type === 'devis') {
        $prefix = getSetting('prefixe_devis', 'DEV');
    } elseif ($type === 'facture') {
        $prefix = getSetting('prefixe_facture', 'FACT');
    } else {
        $prefix = getSetting('prefixe_bon_livraison', 'BL');
    }
    $like = $prefix . '-' . $year . '-%';

    // Verrouillage simple : on relit le max existant pour cette année/ce type dans une transaction.
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT numero FROM documents WHERE type = ? AND numero LIKE ? ORDER BY id DESC LIMIT 1 FOR UPDATE");
        $stmt->execute([$type, $like]);
        $last = $stmt->fetchColumn();
        $nextSeq = 1;
        if ($last) {
            $parts = explode('-', $last);
            $nextSeq = ((int)end($parts)) + 1;
        }
        $numero = sprintf('%s-%s-%03d', $prefix, $year, $nextSeq);
        $pdo->commit();
        return $numero;
    } catch (Exception $e) {
        $pdo->rollBack();
        throw $e;
    }
}

// --- Tâches (relances programmées par l'utilisateur, façon HubSpot) ---
const TACHES_TYPES = ['Appel', 'Email', 'Réunion', 'WhatsApp', 'LinkedIn', 'Message', 'Autre'];

function getTachesOuvertes(int $limit = 0): array
{
    $sql = "
        SELECT t.*, c.prenom, c.nom, e.nom AS etablissement_nom
        FROM taches t
        JOIN contacts c ON c.id = t.contact_id
        LEFT JOIN etablissements e ON e.id = c.etablissement_id
        WHERE t.statut = 'a_faire' AND t.date_prevue <= CURDATE()
        ORDER BY t.date_prevue ASC
    ";
    if ($limit > 0) {
        $sql .= ' LIMIT ' . (int)$limit;
    }
    return getPDO()->query($sql)->fetchAll();
}

function getProchaineTacheParContact(): array
{
    // Retourne [contact_id => date_prevue] pour la tâche "à faire" la plus proche de chaque contact.
    $rows = getPDO()->query("
        SELECT contact_id, MIN(date_prevue) AS date_prevue
        FROM taches
        WHERE statut = 'a_faire'
        GROUP BY contact_id
    ")->fetchAll();
    $result = [];
    foreach ($rows as $r) {
        $result[(int)$r['contact_id']] = $r['date_prevue'];
    }
    return $result;
}

// --- Calcul de la date de fin de garantie ---
function calculerFinGarantie(?string $dateFinReelle, int $garantieMois): ?string
{
    if (empty($dateFinReelle)) {
        return null;
    }
    $ts = strtotime($dateFinReelle . " + {$garantieMois} months");
    return $ts ? date('Y-m-d', $ts) : null;
}

// --- Envoi d'email simple (utilisé pour les alertes) ---
function envoyerEmail(string $to, string $subject, string $bodyHtml): bool
{
    if (empty($to) || empty(EMAIL_FROM)) {
        return false;
    }
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= 'From: ' . EMAIL_FROM_NAME . ' <' . EMAIL_FROM . ">\r\n";
    return @mail($to, $subject, $bodyHtml, $headers);
}

---
title: Guide de déploiement — CRM Fibromed (version 2)
---

# Guide de déploiement — CRM Fibromed

Ce guide explique comment mettre le CRM en ligne sur votre hébergement Hodi. Il est écrit pour être suivi **à la lettre, étape par étape**, même sans connaissances techniques.

## Qui doit faire l'installation ? Vous, ou votre hébergeur ?

**Les deux sont possibles.**

**Option A — Vous demandez à Hodi de l'installer pour vous (le plus simple).**
La plupart des hébergeurs, dont Hodi, proposent un support technique qui peut faire cette installation à votre place, gratuitement ou pour un petit forfait. C'est une installation standard pour eux (créer une base MySQL, uploader des fichiers PHP, exécuter un script) — ils font ça tous les jours. Vous pouvez leur envoyer telle quelle l'archive `crm-fibromed.zip` reçue, accompagnée du message suivant (à copier-coller dans un ticket support ou un email à Hodi) :

> Bonjour, je souhaite installer une application web (PHP + MySQL) sur mon hébergement. Voici ce dont j'ai besoin :
> 1. Créer une base de données MySQL (je vous laisse choisir le nom, par exemple `fibromed_crm`) avec un utilisateur ayant tous les droits dessus.
> 2. Uploader le contenu du dossier joint `crm-fibromed` à la racine d'un sous-domaine, par exemple `crm.fibromed.ma` (à créer si besoin).
> 3. Dans le dossier `config/`, dupliquer `config.sample.php` en `config.php` et le remplir avec les identifiants de la base créée à l'étape 1 (voir les commentaires dans le fichier).
> 4. Ouvrir `https://crm.fibromed.ma/install.php` dans un navigateur pour finaliser l'installation, puis supprimer ce fichier.
> 5. Activer le certificat SSL (HTTPS) gratuit sur ce sous-domaine.
> Merci !

**Option B — Vous le faites vous-même.** Comptez 30 à 45 minutes la première fois. Suivez les étapes ci-dessous, dans l'ordre, sans en sauter aucune.

Les deux options donnent exactement le même résultat. Ce guide couvre l'option B en détail.

## Ce que vous avez reçu

Un dossier (ou fichier zip) `crm-fibromed` contenant :

- Les fichiers de l'application (pages `.php`, dossiers `assets/`, `includes/`, `lib/`)
- `sql/schema.sql` — la structure de la base de données
- `config/config.sample.php` — le modèle de fichier de configuration à remplir
- `install.php` — un script qui crée automatiquement les tables et votre compte
- `cron_relances.php` — le script des rappels automatiques par email
- Ce guide

## Avant de commencer — ce qu'il vous faut

- Vos identifiants d'accès au panel d'hébergement Hodi (ceux que vous utilisez déjà pour gérer le site fibromed.ma).
- 30 à 45 minutes sans être interrompu, la première fois.
- Un ordinateur (l'installation via le gestionnaire de fichiers du panel Hodi est plus simple sur ordinateur que sur mobile).

Le CRM a aussi besoin, côté serveur : **PHP 8.0 ou supérieur** avec l'extension `PDO MySQL` (standard et activée par défaut chez Hodi), et **une base de données MySQL**. Vous pouvez vérifier la version de PHP dans le panel Hodi, généralement dans une rubrique "PHP" ou "Sélecteur de version PHP" — si elle affiche 8.0, 8.1, 8.2, 8.3 ou plus, c'est bon.

## Étape 1 — Créer la base de données MySQL sur Hodi

1. Connectez-vous à votre panel d'hébergement Hodi.
2. Cherchez la rubrique **"Bases de données MySQL"** (souvent dans une section "Bases de données").
3. Créez une nouvelle base, par exemple nommée `fibromed_crm`.
4. Créez un utilisateur MySQL dédié (par exemple `fibromed_user`) avec un mot de passe fort, et attribuez-lui **tous les droits** sur cette base.
5. **Notez précisément ces informations sur un papier ou dans un fichier texte** — vous en aurez besoin à l'étape 4 :
   - Nom de la base (souvent préfixé automatiquement par votre compte, ex. `monlogin_fibromed_crm`)
   - Nom d'utilisateur MySQL (souvent préfixé aussi)
   - Mot de passe choisi
   - L'hôte est presque toujours `localhost`

Si vous ne trouvez pas cette rubrique, cherchez "MySQL" dans la barre de recherche du panel Hodi, ou contactez le support Hodi en leur demandant "comment créer une base de données MySQL".

## Étape 2 — Choisir où le CRM sera accessible

Deux options :

- **Sous-domaine dédié (recommandé)** : créez un sous-domaine `crm.fibromed.ma` depuis le panel Hodi (rubrique "Sous-domaines" ou "Domaines"). Le CRM sera accessible à `https://crm.fibromed.ma`. C'est l'option la plus propre.
- **Dossier du site existant** : par exemple `fibromed.ma/crm`. Fonctionne aussi.

Notez l'adresse choisie, vous en aurez besoin à l'étape 4.

## Étape 3 — Uploader les fichiers

1. Dans le panel Hodi, ouvrez le **gestionnaire de fichiers** (ou utilisez un client FTP comme FileZilla si vous êtes à l'aise avec).
2. Repérez le dossier correspondant au sous-domaine créé à l'étape 2 (souvent nommé automatiquement, par exemple visible sous `public_html/crm.fibromed.ma/`).
3. Uploadez **tout le contenu** du dossier `crm-fibromed` reçu (attention : le *contenu* du dossier, pas le dossier lui-même) à la racine de ce dossier. Si vous avez reçu un fichier `.zip`, le gestionnaire de fichiers Hodi propose généralement une option "Uploader" puis "Extraire" — uploadez le zip puis extrayez-le directement au bon endroit.
4. Vérifiez que vous voyez bien, à la racine, des fichiers comme `install.php`, `login.php`, et des dossiers `assets`, `includes`, `config`, `sql`, `lib`.

## Étape 4 — Configurer la connexion à la base de données

1. Dans le gestionnaire de fichiers, ouvrez le dossier `config/`.
2. Dupliquez (copier-coller) le fichier `config.sample.php` et renommez la copie en **`config.php`** exactement (respectez les minuscules).
3. Éditez `config.php` (clic droit → Éditer, ou "Code Editor" selon le panel) et remplissez avec les informations notées à l'étape 1 :

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'monlogin_fibromed_crm');
define('DB_USER', 'monlogin_fibromed_user');
define('DB_PASS', 'votre_mot_de_passe');
define('BASE_URL', 'https://crm.fibromed.ma');
```

4. Remplacez uniquement le texte entre guillemets (`'...'`) — ne touchez pas au reste de la ligne. `BASE_URL` doit correspondre exactement à l'adresse choisie à l'étape 2, sans `/` à la fin.
5. Enregistrez le fichier.

**Erreur fréquente à éviter** : bien renommer le fichier en `config.php` (pas `config.sample.php` modifié, ni `config (1).php`). Si le nom est incorrect, l'application ne le trouvera pas.

## Étape 5 — Lancer l'installation

1. Ouvrez `https://crm.fibromed.ma/install.php` dans votre navigateur (remplacez par votre propre adresse si différente).
2. Le script crée automatiquement les tables de la base de données — un message vert de confirmation s'affiche.
   - Si vous voyez à la place un message "Erreur de connexion à la base de données", retournez à l'étape 4 : un des identifiants dans `config.php` est probablement incorrect.
3. Remplissez le formulaire pour créer votre compte administrateur (nom complet, identifiant de connexion, mot de passe d'au moins 8 caractères). Notez ce mot de passe quelque part de sûr.
4. Cliquez sur "Créer le compte administrateur".
5. **Étape de sécurité importante** : une fois le compte créé, supprimez le fichier `install.php` du serveur (clic droit → Supprimer dans le gestionnaire de fichiers). Ce fichier ne doit pas rester accessible une fois l'installation terminée. Si vous oubliez, ce n'est pas grave dans l'immédiat : le script se bloque automatiquement dès qu'un compte existe — mais il vaut mieux le supprimer.

## Étape 6 — Se connecter

Rendez-vous sur `https://crm.fibromed.ma/login.php` et connectez-vous avec le compte créé à l'étape 5. Vous arrivez directement sur le tableau de bord.

## Étape 7 — Compléter les paramètres

Allez dans **Paramètres** (menu de gauche) pour vérifier que tout est correct :

- Les informations légales (RC, IF, ICE, adresse) sont déjà pré-remplies avec les informations de Fibromed — vérifiez-les.
- Les coordonnées du gérant (nom, téléphone, email) sont déjà pré-remplies avec vos informations — elles apparaissent en bas de chaque devis et facture.
- La clause juridique de réserve de propriété est déjà pré-remplie et s'affiche automatiquement sur tous les devis — vous pouvez la modifier ici si besoin un jour.
- Renseignez l'**email pour les alertes automatiques** (nécessaire pour l'étape 8).

## Étape 8 — Activer les rappels automatiques par email (optionnel mais recommandé)

Le fichier `cron_relances.php` vérifie chaque jour vos tâches à faire, les factures en retard et les garanties bientôt expirées, puis vous envoie un email récapitulatif.

1. Dans `cron_relances.php`, remplacez `changez-ce-jeton-secret` par un mot de passe secret de votre choix (utile seulement si vous déclenchez le script par une URL plutôt qu'en tâche planifiée — voir ci-dessous).
2. Dans le panel Hodi, cherchez la rubrique **"Tâches planifiées"** (ou "Cron Jobs").
3. Créez une tâche quotidienne (par exemple tous les jours à 8h00) qui exécute :

```
php /home/votre-compte/crm.fibromed.ma/cron_relances.php
```

(le chemin exact dépend de l'endroit où vous avez uploadé les fichiers — le gestionnaire de fichiers Hodi affiche le chemin complet si vous cliquez sur "Propriétés" du dossier).

Si votre offre Hodi ne permet pas les tâches planifiées, ignorez cette étape : les alertes resteront visibles directement dans le tableau de bord du CRM à chaque connexion (section "Tâches à faire").

## Étape 9 — Votre logo

Votre logo Fibromed est déjà intégré dans l'application que vous avez reçue (`assets/img/logo-fibromed.jpg`) et s'affiche automatiquement en en-tête de tous les devis, factures et bons de livraison. Vous n'avez rien à faire pour cette étape — elle est indiquée ici uniquement si vous deviez un jour le remplacer : il suffit de remplacer ce fichier par une nouvelle image du même nom.

## Sécurité et bonnes pratiques

- **HTTPS** : activez le certificat SSL gratuit (Let's Encrypt) proposé par Hodi pour votre sous-domaine, afin que le CRM soit accessible en `https://`.
- **Sauvegardes** : exportez régulièrement votre base de données depuis phpMyAdmin (panel Hodi → "Bases de données" → "phpMyAdmin" → sélectionner la base → "Exporter"). Une fois par semaine est un bon rythme, surtout avant toute modification importante.
- **Mot de passe** : vous pouvez le changer à tout moment depuis la page Paramètres du CRM.
- Les dossiers `config/`, `includes/`, `lib/` et `sql/` sont protégés par des fichiers `.htaccess` qui bloquent leur accès direct depuis un navigateur — ne les supprimez pas.

## En cas de problème

| Symptôme | Cause probable | Solution |
|---|---|---|
| "Erreur de connexion à la base de données" | Les identifiants dans `config/config.php` sont incorrects | Revérifiez le nom de base, l'utilisateur et le mot de passe (étape 4) |
| Page blanche | Version PHP trop ancienne | Vérifiez PHP 8.0+ dans le panel Hodi (rubrique "Sélecteur de version PHP") |
| "L'installation a déjà été effectuée" en ouvrant install.php | Normal si un compte existe déjà | Allez directement sur `login.php` |
| Le logo ne s'affiche pas sur les PDF | Le fichier `assets/img/logo-fibromed.jpg` n'a pas été uploadé correctement | Vérifiez qu'il est bien présent dans `assets/img/` sur le serveur |
| Les accents ne s'affichent pas bien sur les PDF | Cas rare, encodage serveur particulier | Contactez-moi, un ajustement peut être nécessaire |

Si un problème persiste, faites une capture d'écran du message d'erreur exact — cela permet de le résoudre beaucoup plus vite.

## Note technique

Le CRM utilise la bibliothèque libre **FPDF** (licence libre, gratuite y compris en usage commercial) pour générer les PDF, incluse directement dans le dossier `lib/` — aucune installation supplémentaire n'est nécessaire sur votre hébergement. L'application ne nécessite ni Composer, ni accès SSH, ni aucune dépendance externe : elle fonctionne sur un hébergement mutualisé standard comme Hodi.

---

Pour toute question ou évolution du CRM, revenez vers la conversation où ce projet a été construit.

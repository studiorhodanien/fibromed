<?php
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/pdf_document.php';

requireLogin();

$id = (int)($_GET['id'] ?? 0);
$mode = ($_GET['dl'] ?? '') === '1' ? 'D' : 'I';

try {
    generateDocumentPdf($id, $mode);
} catch (Exception $e) {
    http_response_code(404);
    echo 'Document introuvable.';
}

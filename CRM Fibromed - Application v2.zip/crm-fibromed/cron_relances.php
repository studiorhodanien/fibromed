<?php
/**
 * Script à exécuter une fois par jour (tâche planifiée / cron) pour envoyer les
 * emails de rappel : relances du jour, factures en retard, garanties bientôt expirées.
 *
 * Sur Hodi, ce script se programme généralement depuis le panel d'hébergement
 * (rubrique "Tâches planifiées" / "Cron Jobs"), par exemple une fois par jour à 8h :
 *   php /home/.../crm/cron_relances.php
 *
 * Si ce script est appelé par une URL plutôt qu'en ligne de commande, il exige
 * un jeton secret (paramètre ?token=) défini ci-dessous, pour éviter que
 * n'importe qui puisse le déclencher depuis l'extérieur.
 */

require_once __DIR__ . '/includes/functions.php';

define('CRON_SECRET', 'changez-ce-jeton-secret'); // à personnaliser avant mise en ligne

$isCli = (php_sapi_name() === 'cli');
if (!$isCli) {
    $token = $_GET['token'] ?? '';
    if (!hash_equals(CRON_SECRET, $token)) {
        http_response_code(403);
        die('Accès refusé.');
    }
}

$pdo = getPDO();
$destinataire = getSetting('email_alertes', '');
if (empty($destinataire)) {
    echo "Aucun email d'alerte configuré (voir Paramètres). Rien envoyé.\n";
    exit;
}

$messages = [];

// --- Tâches à faire aujourd'hui (ou en retard) ---
$tachesDuJour = $pdo->query("
    SELECT t.*, c.prenom, c.nom, e.nom AS etablissement_nom
    FROM taches t
    JOIN contacts c ON c.id = t.contact_id
    LEFT JOIN etablissements e ON e.id = c.etablissement_id
    WHERE t.statut = 'a_faire' AND t.date_prevue <= CURDATE()
    ORDER BY t.date_prevue ASC
")->fetchAll();

if (!empty($tachesDuJour)) {
    $lines = ['<h3>Tâches à faire aujourd\'hui</h3><ul>'];
    foreach ($tachesDuJour as $t) {
        $lines[] = '<li>[' . e($t['type']) . '] ' . e($t['prenom'] . ' ' . $t['nom']) . ($t['etablissement_nom'] ? ' (' . e($t['etablissement_nom']) . ')' : '') . ($t['titre'] ? ' — ' . e($t['titre']) : '') . '</li>';
    }
    $lines[] = '</ul>';
    $messages[] = implode('', $lines);
}

// --- Factures en retard ---
$facturesRetard = $pdo->query("
    SELECT d.*, e.nom AS etablissement_nom
    FROM documents d
    LEFT JOIN etablissements e ON e.id = d.etablissement_id
    WHERE d.type='facture' AND d.statut NOT IN ('payé','annulé')
      AND d.date_echeance IS NOT NULL AND d.date_echeance < CURDATE()
")->fetchAll();

if (!empty($facturesRetard)) {
    $lines = ['<h3>Factures en retard de paiement</h3><ul>'];
    foreach ($facturesRetard as $f) {
        $lines[] = '<li>' . e($f['numero']) . ' — ' . e($f['etablissement_nom'] ?? '') . ' — ' . formatMoney($f['total_ttc']) . ' (échéance ' . formatDateFr($f['date_echeance']) . ')</li>';
        // Mise à jour automatique du statut si pas déjà marqué en retard.
        if ($f['statut'] !== 'en_retard') {
            $pdo->prepare("UPDATE documents SET statut = 'en_retard' WHERE id = ?")->execute([$f['id']]);
        }
    }
    $lines[] = '</ul>';
    $messages[] = implode('', $lines);
}

// --- Garanties expirant dans 7 jours (rappel proche) ---
$garanties = $pdo->query("
    SELECT r.*, e.nom AS etablissement_nom,
           DATE_ADD(r.date_fin_reelle, INTERVAL r.garantie_mois MONTH) AS fin_garantie
    FROM reparations r
    LEFT JOIN etablissements e ON e.id = r.etablissement_id
    WHERE r.date_fin_reelle IS NOT NULL
    HAVING fin_garantie = DATE_ADD(CURDATE(), INTERVAL 7 DAY)
")->fetchAll();

if (!empty($garanties)) {
    $lines = ['<h3>Garanties expirant dans 7 jours</h3><ul>'];
    foreach ($garanties as $g) {
        $lines[] = '<li>' . e(trim(($g['marque'] ?? '') . ' ' . ($g['modele'] ?? ''))) . ' — ' . e($g['etablissement_nom'] ?? '') . ' (fin le ' . formatDateFr($g['fin_garantie']) . ')</li>';
    }
    $lines[] = '</ul>';
    $messages[] = implode('', $lines);
}

if (empty($messages)) {
    echo "Rien à signaler aujourd'hui.\n";
    exit;
}

$body = '<div style="font-family:sans-serif;">' . implode('<hr>', $messages) . '</div>';
$sent = envoyerEmail($destinataire, 'CRM Fibromed — Rappels du jour', $body);

echo $sent ? "Email de rappel envoyé à $destinataire.\n" : "Échec de l'envoi de l'email (vérifiez la configuration mail() de l'hébergement).\n";

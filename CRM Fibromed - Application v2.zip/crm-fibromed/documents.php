<?php
$pageTitle = 'Devis & Factures';
$activeNav = 'documents';
require_once __DIR__ . '/includes/layout_start.php';

$pdo = getPDO();
$filtreType = $_GET['type'] ?? '';
$filtreStatut = $_GET['statut'] ?? '';
$recherche = trim($_GET['q'] ?? '');

$where = [];
$params = [];
if ($filtreType !== '') { $where[] = 'd.type = ?'; $params[] = $filtreType; }
if ($filtreStatut !== '') { $where[] = 'd.statut = ?'; $params[] = $filtreStatut; }
if ($recherche !== '') {
    $where[] = '(d.numero LIKE ? OR e.nom LIKE ?)';
    $like = '%' . $recherche . '%';
    $params[] = $like; $params[] = $like;
}
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$sql = "
    SELECT d.*, e.nom AS etablissement_nom
    FROM documents d
    LEFT JOIN etablissements e ON e.id = d.etablissement_id
    $whereSql
    ORDER BY d.date_emission DESC, d.id DESC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$documents = $stmt->fetchAll();

$statutsListe = ['brouillon' => 'Brouillon', 'envoyé' => 'Envoyé', 'accepté' => 'Accepté', 'payé' => 'Payé', 'en_retard' => 'En retard', 'annulé' => 'Annulé'];
$typeLabels = ['devis' => 'Devis', 'facture' => 'Facture', 'bon_livraison' => 'Bon de livraison'];
if (!function_exists('statutBadgeClass')) {
    function statutBadgeClass(string $statut): string
    {
        if ($statut === 'payé' || $statut === 'accepté') return 'success';
        if ($statut === 'en_retard') return 'danger';
        if ($statut === 'envoyé') return 'warning';
        if ($statut === 'annulé') return 'grey';
        return '';
    }
}
?>

<div class="page-header">
  <div>
    <h1>Devis & Factures</h1>
    <div class="sub"><?= count($documents) ?> document(s)</div>
  </div>
  <div class="btn-group">
    <a href="document_form.php" class="btn">+ Nouveau devis / facture</a>
    <a href="bon_livraison_form.php" class="btn btn-secondary">+ Nouveau bon de livraison</a>
  </div>
</div>

<form method="get" class="filters-bar card">
  <div class="form-row">
    <label>Recherche</label>
    <input type="text" name="q" value="<?= e($recherche) ?>" placeholder="N°, établissement...">
  </div>
  <div class="form-row">
    <label>Type</label>
    <select name="type">
      <option value="">Tous</option>
      <option value="devis" <?= $filtreType === 'devis' ? 'selected' : '' ?>>Devis</option>
      <option value="facture" <?= $filtreType === 'facture' ? 'selected' : '' ?>>Facture</option>
      <option value="bon_livraison" <?= $filtreType === 'bon_livraison' ? 'selected' : '' ?>>Bon de livraison</option>
    </select>
  </div>
  <div class="form-row">
    <label>Statut</label>
    <select name="statut">
      <option value="">Tous</option>
      <?php foreach ($statutsListe as $key => $label): ?>
        <option value="<?= e($key) ?>" <?= $filtreStatut === $key ? 'selected' : '' ?>><?= e($label) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button type="submit" class="btn btn-secondary">Filtrer</button>
  <a href="documents.php" class="btn btn-secondary">Réinitialiser</a>
</form>

<?php if (empty($documents)): ?>
  <div class="card empty-state">Aucun document pour le moment.</div>
<?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>N°</th><th>Type</th><th>Établissement</th><th>Émission</th><th>Échéance</th><th>Statut</th><th>Total TTC</th><th></th></tr></thead>
      <tbody>
        <?php foreach ($documents as $d): ?>
          <?php $isBl = $d['type'] === 'bon_livraison'; ?>
          <tr>
            <td><?= e($d['numero']) ?></td>
            <td><?= e($typeLabels[$d['type']] ?? $d['type']) ?></td>
            <td><?= e($d['etablissement_nom'] ?: '—') ?></td>
            <td><?= formatDateFr($d['date_emission']) ?></td>
            <td><?= $isBl ? '—' : formatDateFr($d['date_echeance']) ?></td>
            <td><?= $isBl ? ($d['statut'] === 'brouillon' ? '<span class="badge">Brouillon</span>' : '<span class="badge success">Remis au client</span>') : '<span class="badge ' . statutBadgeClass($d['statut']) . '">' . e($statutsListe[$d['statut']] ?? $d['statut']) . '</span>' ?></td>
            <td><?= $isBl ? '—' : formatMoney($d['total_ttc']) ?></td>
            <td class="btn-group">
              <a href="<?= $isBl ? 'bon_livraison_view.php' : 'document_view.php' ?>?id=<?= (int)$d['id'] ?>" class="btn btn-sm btn-secondary">Voir</a>
              <a href="<?= $isBl ? 'bon_livraison_pdf.php' : 'document_pdf.php' ?>?id=<?= (int)$d['id'] ?>" target="_blank" class="btn btn-sm btn-secondary">PDF</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<?php require_once __DIR__ . '/includes/layout_end.php'; ?>
